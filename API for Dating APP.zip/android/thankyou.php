<?php
include 'config.php';
include 'instamojo.php';
$api = new Instamojo\Instamojo('95df123614ae43b0a1ff95fa38ef7d48', '75533879abde9b6c289557641bcc8333');
$payid = $_GET["payment_request_id"];
$paid = $_GET["payment_id"];
try {
    $response = $api->paymentRequestStatus($payid,$paid);
if($response['payments'][0]['status']=="Credit"){
$user=$_SESSION['user'];
$day=$_SESSION['planday'];
if($day=='1month'){
$end_date=date('Y-m-d', strtotime("+30 days"));
}
elseif($day=='3month'){
$end_date=date('Y-m-d', strtotime("+90 days"));
}
elseif($day=='6month'){
$end_date=date('Y-m-d', strtotime("+180 days"));
}
else{
$end_date=date('Y-m-d', strtotime("+0 days"));
}
$start_date=date('Y-m-d');
$plant=$response['purpose'];
$amount=$response['amount'];
$order=$response['id'];
$payment=$response['payments'][0]['payment_id'];
mysql_query("insert into tbl_userplan(user_id,plan_type,start_date,end_date,payment_id,order_id,amount)values('$user','$plant','$start_date','$end_date','$payment','$order','$amount')");
echo "<h1 style='text-align:center;color:green'>Cheers ! Payment Succeed</h1>";
header("refresh:2;url=indiandating-myprofile.php");
}
else{
$user=$_SESSION['user'];
$day=$_SESSION['planday'];
if($day=='1month'){
$end_date=date('Y-m-d', strtotime("+30 days"));
}
elseif($day=='3month'){
$end_date=date('Y-m-d', strtotime("+90 days"));
}
elseif($day=='6month'){
$end_date=date('Y-m-d', strtotime("+180 days"));
}
else{
$end_date=date('Y-m-d', strtotime("+0 days"));
}
$start_date=date('Y-m-d');
$plant=$response['purpose'];
$amount=$response['amount'];
$order=$response['id'];
$payment=$response['payments'][0]['payment_id'];
mysql_query("insert into tbl_paymentfail(user_id,plan_type,start_date,end_date,payment_id,order_id,amount)values('$user','$plant','$start_date','$end_date','$payment','$order','$amount')");
echo "<h1 style='text-align:center;color:red'>Sorry ! Payment Failed</h1>";
header("refresh:2;url=free-online-dating.php");
}
    ?>
    <?php
}
catch (Exception $e) {
    print('Error: ' . $e->getMessage());
}



  ?>  

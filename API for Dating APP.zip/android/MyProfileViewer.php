<?php

if($_SERVER["REQUEST_METHOD"]=="GET")
{
	
	
	include "config.php";	
	
	
	if(isset($_GET['LoadData']))    
    	{	
    		$limit=$_GET['limit'];
		
		$userid=$_GET['cuserid'];
    	
    		$resulta="select tbl_viewer.id, tbl_viewer.profile,tbl_viewer.viewer,tbl_viewed_profile.time,tbl_user.name from tbl_viewer
inner join tbl_user
on tbl_user.id=tbl_viewer.profile
where tbl_viewer.id=$userid ORDER BY intId DESC LIMIT 0,$limit"; 	
	
		

		$result=mysqli_query($con,$resulta);
		$response=array();

		if(mysqli_num_rows($result)>0){

         		while($row=mysqli_fetch_array($result))
         		{
	         		if($row)
	         		{
		          		array_push($response,array(
                          		"intId"=>$row["id"],   
                          		"intVieweeId"=>$row["viewer"],  
                          		"createdate"=>$row["time"],     		
      		          		"fname"=>$row["name"]
		          				          		
		         		));
		        
	        		}
	        		else
	        		{
		        		$response["error"] = TRUE;
		        		echo json_encode($response);
	        		}              

       			}
		echo json_encode($response);

		}
		
	
		
}
if(isset($_GET['MoreData']))
{

	$limit=$_GET['limit'];
	$lastGetDataLength=$_GET['lastGetDataLength'];
	$userid=$_GET['cuserid'];
	
	
	$resulta="select tbl_viewed_profile.intId, tbl_viewed_profile.intViewerId,tbl_viewed_profile.intVieweeId,tbl_viewed_profile.createdate,tbl_signup.fname from tbl_viewed_profile
inner join tbl_signup
on tbl_signup.intId=tbl_viewed_profile.intViewerId
where tbl_viewed_profile.intVieweeId=$userid ORDER BY intId DESC LIMIT $lastGetDataLength,$limit"; 	


		$result=mysqli_query($con,$resulta);
		$response=array();

		if(mysqli_num_rows($result)>0){

         		while($row=mysqli_fetch_array($result))
         		{
	         		if($row)
	         		{
		          		array_push($response,array(
                          		"intId"=>$row["intId"],   
                          		"intRecrid"=>$row["intRecrid"],  
                          		"createdate"=>$row["createdate"],     		
      		          		"fname"=>$row["fname"]
		          				          		
		         		));
		        
	        		}
	        		else
	        		{
		        		$response["error"] = TRUE;
		        		echo json_encode($response);
	        		}              

       			}
		echo json_encode($response);

		}
}

}

?>
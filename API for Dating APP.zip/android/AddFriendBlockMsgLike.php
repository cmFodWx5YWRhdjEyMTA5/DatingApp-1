<?php

if($_SERVER["REQUEST_METHOD"]=="POST")
{	
	include "config.php";	
	
	
	if(isset($_POST['addAs']))    
    	{	    		
		$cuserid=$_POST['currentid']; 
		$userid=$_POST['vuserid'];		
		$useraddas=$_POST['addAs'];  
		
		
		
		
		if($useraddas=="F1")  	
		{
		
			$countryQuery="select * from tbl_friendrequests where user='$cuserid' and receiver='$userid'";    			
			$friendchk="select * from  tbl_friends where (user='$cuserid' and friend='$userid') or (user='$userid' and friend='$cuserid')";  
					
    			$result=mysqli_query($con,$countryQuery);
    			
    			$resul2=mysqli_query($con,$friendchk);
    		
    			if(mysqli_num_rows($result)>0)
			{		
				echo "AlreadySent";		
			}
			else if(mysqli_num_rows($resul2)>0)
			{
			
				echo "AlreadySent";
			}
			else
			{				
				$addfriend="insert into tbl_friendrequests (user,receiver)VALUES('$cuserid','$userid')"; 			
			
				if(mysqli_query($con,$addfriend))
				{			
					echo "F1";
				}
				else
				{
					echo "F0";			
				}	
		
			}			
		
		}
		
		if($useraddas=="AF")  	
		{
		
					
				$addfriend="insert into tbl_friends(user,friend)VALUES('$cuserid','$userid')"; 			
			
				if(mysqli_query($con,$addfriend))
				{	
				
					$remfriend="delete from tbl_friendrequests where (user='$userid' and receiver='$cuserid') or (user='$cuserid' and receiver='$userid')";
					
					
					if(mysqli_query($con,$remfriend))
					{
						echo "FADDER";
					}	
					else
					{
						echo "FRNotChange";
					}	
					
				}
					
		
						
		
		}
		
		
		
		
		if($useraddas=="RemoveF")  	
		{
		
			$remfriend="delete from tbl_friends where (user='$cuserid' and friend='$userid')or (user='$userid' and friend='$cuserid')";    		
    			
    		
    			if(mysqli_query($con,$remfriend))
			{		
				echo "Removed Friend";		
			}
			else
			{		
				echo "noRemoved";
		
			}			
		
		}
		
		
		else if($useraddas=="RemoveRequest")  	
		{
		
			$canfriend="delete from tbl_friendrequests where user='$cuserid' and receiver='$userid'";    		
    			
    		
    			if(mysqli_query($con,$canfriend))
			{		
				echo "CancelRequest";		
			}
			else
			{		
				echo "noRemoved";
		
			}			
		
		}
		
		
		
		else if($useraddas=="B1")  	
		{
				
				$Blockfriend="insert into tbl_block (user,blocked)VALUES('$cuserid','$userid')"; 			
			
				if(mysqli_query($con,$Blockfriend))
				{			
					echo "B1";
				}
				else
				{
					echo "B0";			
				}	
		
						
		
		}
		else if($useraddas=="BR")  	
		{
				
				$Blockfriend="delete from tbl_block where user='$cuserid' and blocked='$userid'"; 			
			
				if(mysqli_query($con,$Blockfriend))
				{			
					echo "BlockRemove";
				}
				else
				{
					echo "B0";			
				}	
		
						
		
		}
		else if($useraddas=="L1")  	
		{
		
			$likeQuery="select * from  tbl_likes where user='$cuserid' and likes='$userid'";    		
    			$result=mysqli_query($con,$likeQuery);
    		
    			if(mysqli_num_rows($result)>0)
			{		
				echo "AlreadyLike";		
			}
			else
			{		
				$Blockfriend="insert into tbl_likes (user,likes)VALUES('$cuserid','$userid')"; 			
			
				if(mysqli_query($con,$Blockfriend))
				{			
					echo "L1";
				}
				else
				{
					echo "L0";			
				}	
		
			}			
		
		}
		else if($useraddas=="RemoveLike")  	 
		{
			$Blockfriend="delete from tbl_likes where user='$cuserid' and likes='$userid'"; 			
			
				if(mysqli_query($con,$Blockfriend))
				{			
					echo "removeLike";
				}
				else
				{
					echo "NoremoveLike";			
				}	
		
						
		
		}
		else if($useraddas=="M1")  	
		{
			$usermessage=$_POST['message']; 
		
			$likeQuery="select * from  tbl_message where sender='$cuserid' and receiver='$userid'";    		
    			$result=mysqli_query($con,$likeQuery);
    		
    			if(mysqli_num_rows($result)>0)
			{		
				echo "1message";		
			}
			else
			{		
				$messagefriend="insert into tbl_message (sender,receiver,message)VALUES('$cuserid','$userid','$usermessage')"; 			
			
				if(mysqli_query($con,$messagefriend))
				{			
					echo "M1";
				}
				else
				{
					echo "M0";			
				}	
		
			}			
		
		}
		
		
		
		
    	
		
	
		
	}
	

}
else
{

echo "server";

}





?>
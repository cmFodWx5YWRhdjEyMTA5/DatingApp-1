<?php

if($_SERVER["REQUEST_METHOD"]=="POST")
{
	include "config.php";	
	
	$userid =$_POST['id'];
	$newmessage= $_POST['newmessage'];
	$interestedinme= $_POST['interestedinme'];
	$friendrequest= $_POST['friendrequest'];
	$profilevisitors= $_POST['profilevisitors'];
	
	
	//$isnotification=$_POST['Notification'];
	
	
    		$resu="select * from tbl_notification where userid='$userid'"; 	   		
    		
    		
		$result=mysqli_query($con,$resu);
		
		if(mysqli_num_rows($result)>0)
		{
		
				    		
       		
				$resulta="update tbl_notification set newmessage='$newmessage',intrestedinme='$interestedinme',friendrequest='$friendrequest',profilevisitor='$profilevisitors'"; 	   		
    		
				if(mysqli_query($con,$resulta))
				{				
				
					echo "Updated";
				}
				else
				{
					echo "try again";
		
				}  	
    			
			
		
					
		}
		else
		{
		      		
				$resulta="insert into  tbl_notification(newmessage,intrestedinme,friendrequest,profilevisitor,userid)VALUES('$newmessage','$interestedinme','$friendrequest','$profilevisitors','$userid')"; 	   		
    		
				if(mysqli_query($con,$resulta))
				{				
				
					echo "Notification Inserted";
				}
				else
				{
					echo "try again";
		
				}  	
    			
		}
	
	
	
	
	
}

?>
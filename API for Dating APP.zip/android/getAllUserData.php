<?php
 include("config.php");
	$queri="select * from tbl_user ";                    
	$result=mysqli_query($con,$queri) or die("Query Not Executed " . mysqli_error($con));
    $response=array();

			while ($row=mysqli_fetch_array($result)) 
			{
			        array_push($response, array(
					"id"=>$row['id'],                             		 		
      		          		"name"=>$row['name'],
      		          		"gender"=>$row['gender'],	
      		          		"birthday"=>$row['birthday'],
      		          		 "city"=>$row['birthday'],                     		 		    		          		          		          				          		
      		          		"profile_pic"=>$row['profile_pic'],
      		          		"friend"=>$alFriend,
					));

				}
			
				echo json_encode($response);
			
		?>
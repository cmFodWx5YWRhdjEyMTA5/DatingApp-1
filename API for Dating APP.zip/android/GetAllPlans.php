<?php

if($_SERVER["REQUEST_METHOD"]=="POST")
{	
	include "config.php";	
	
	if(isset($_POST['GetStandard']))    	
    	{	
    		$load1=$_POST['GetStandard'];  		
    		
    		
    		if($load1=="1")
    		{
    			$limit1=$_POST['limit'];  
    			$response1=array();		
		
			$resulta="SELECT id,name,duration,price,new from tbl_plan where name='standard'";
		
			$result1=mysqli_query($con,$resulta);	
		
		
			if(mysqli_num_rows($result1)>0){
		

         			while($row=mysqli_fetch_array($result1))
         			{
	         			array_push($response1,array(                          		 
	         			 "id"=>$row['id'],                             		 		
      		          		"name"=>$row['name'],
      		          		"duration"=>$row['duration'],	
      		          		"price"=>$row['price'],      		          	                  		 		    		          		          		          				          		
      		          		"new"=>$row['new']     		          		
      		          			      		          		   				          		
		         		));    			
	         		
	        		}
	        		     
			echo json_encode($response1);
       			}
       			
       			  			
		}
		
		
		}
		
		
		else if(isset($_POST['GetPlatinum']))    	
    		{	
    		$load1=$_POST['GetPlatinum'];
    		
    		
    		
    		if($load1=="1")
    		{
    		$limit1=$_POST['limit'];  
    		$response1=array();
		
		
		$resulta="SELECT id,name,duration,price,new from tbl_plan where name='platinum'";
		
			
		
		$result1=mysqli_query($con,$resulta);	
		
		
		if(mysqli_num_rows($result1)>0){
		

         		while($row=mysqli_fetch_array($result1))
         		{
	         			array_push($response1,array(                          		 
	         			 "id"=>$row['id'],                             		 		
      		          		"name"=>$row['name'],
      		          		"duration"=>$row['duration'],	
      		          		"price"=>$row['price'],      		          	                  		 		    		          		          		          				          		
      		          		"new"=>$row['new']     		          		
      		          			      		          		   				          		
		         		));    			
	         		
	        	}
	        	
	        	echo json_encode($response1);
	        		     

       		}
       			
       			  			
		}
		
		
		}
		else
		{
		
		echo "go in else";	
		
		}

	}
	
?>
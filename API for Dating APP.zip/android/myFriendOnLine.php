<?php

if($_SERVER["REQUEST_METHOD"]=="POST")
{	
	include "config.php";	
	
	if(isset($_POST['GetAllFriend']))    	
    	{	
    		$load1=$_POST['GetAllFriend'];
    		$cuserid=$_POST['cuserid'];  
    		
    		if($load1=="1")
    		{
    		
    		$response1=array();
		
		
		$resulta="SELECT * from  tbl_friends where user='$cuserid' LIMIT 0,20";
		
		$end=mysql_num_rows($resulta);
		
		
		$result1=mysqli_query($con,$resulta);	
		
		
		if(mysqli_num_rows($result1)>0){
		

         		while($row=mysqli_fetch_array($result1))
         		{
	         		if($row)
	         		{  
	         			
	         		
	         			$friendid=$row['friend'];
	         			
	         			$QfridDtl="SELECT tbl_user.id, tbl_user.name,  tbl_user.gender, tbl_user.birthday, tbl_user.profile_pic, tbl_userdetail.city FROM tbl_user INNER JOIN tbl_userdetail ON tbl_user.id = tbl_userdetail.user where tbl_user.id='$friendid'";
	         			
	         			$RQfdtl=mysqli_query($con,$QfridDtl);
	         			while($roww=mysqli_fetch_array($RQfdtl))
         				{
         					if($roww)
	         				{ 
	         					$citycode1=$roww['city'];
	         					$Qscity1="Select * from cities where id='$citycode1'";
	         					$rcity1=mysqli_query($con,$Qscity1);
	         					$fcity1= mysqli_fetch_array($rcity1); 
	         					$city1=$fcity1["name"];	
	         					
	         					
	         					
	         				
	         					array_push($response1,array(                          		 
	         			 		"id"=>$roww['id'],                             		 		
      		          				"name"=>$roww['name'],
      		          				"gender"=>$roww['gender'],	
      		          				"birthday"=>$roww['birthday'],
      		          		 		"city"=>$city1,                     		 		    		          		          		          				          		
      		          				"profile_pic"=>$roww['profile_pic']	      		          		   				          		
		         				));
	         				}
         				}
         				
         				
         				
	         			
	         			/*
	         			$Qcitygetc=mysqli_query($con,$Qcity);
	         			$fcitygetc= mysqli_fetch_array($Qcitygetc); 
	         			$citycode=$fcitygetc["city"];	
	         		
	         			
	         		
	         			if($citycode)
	         			{	         			
	         			$Qscity1="Select * from cities where id='$citycode'";
	         			$rcity1=mysqli_query($con,$Qscity1);
	         			$fcity1= mysqli_fetch_array($rcity1); 
	         			$city1=$fcity1["name"];	
	         			}
	         		 	        		
	         			$resulta="SELECT tbl_user.id, tbl_user.name,  tbl_user.gender, tbl_user.birthday, tbl_user.profile_pic, tbl_userdetail.city FROM tbl_user INNER JOIN tbl_userdetail ON tbl_user.id = tbl_userdetail.user LIMIT 0,20";	     		
	         				     							
	         			
	         			
	         			$citycode1=$row['city'];
	         			$Qscity1="Select * from cities where id='$citycode1'";
	         			$rcity1=mysqli_query($con,$Qscity1);
	         			$fcity1= mysqli_fetch_array($rcity1); 
	         			$city1=$fcity1["name"];		*/         			         			
	         			       			
	         		
	         			    			
	         		
	        		}
	        		     

       			}
       			echo json_encode($response1);
       			
       			
       			
       			  			
		}
		else
		{
		echo "o friend";
		
		}
		
		}
		else
		{
		
		echo "go in else";	
		
		}
	

	}
	
	
	if(isset($_POST['moredta']))    	
    	{		
    		$load1=$_POST['moredta'];
    		$cnext=$_POST['next'];
    		$cuserid=$_POST['cuserid'];  
    		
    		if($load1=="more")
    		{
    		
    		$response1=array();
		
		
		$resulta="SELECT * from  tbl_friends where user='$cuserid' LIMIT '$cnext',20";
		
		$end=mysql_num_rows($resulta);
		
		
		$result1=mysqli_query($con,$resulta);	
		
		
		if(mysqli_num_rows($result1)>0){
		

         		while($row=mysqli_fetch_array($result1))
         		{
	         		if($row)
	         		{  
	         			$city1="";
	         		
	         			$friendid=$row['friend'];
	         			
	         			$QfridDtl="SELECT tbl_user.id, tbl_user.name,  tbl_user.gender, tbl_user.birthday, tbl_user.profile_pic, tbl_userdetail.city FROM tbl_user INNER JOIN tbl_userdetail ON tbl_user.id = tbl_userdetail.user where tbl_user.id='$friendid'";
	         			
	         			$RQfdtl=mysqli_query($con,$QfridDtl);
	         			while($roww=mysqli_fetch_array($RQfdtl))
         				{
         					if($roww)
	         				{ 
	         					$citycode1=$roww['city'];
	         					$Qscity1="Select * from cities where id='$citycode1'";
	         					$rcity1=mysqli_query($con,$Qscity1);
	         					$fcity1= mysqli_fetch_array($rcity1); 
	         					$city1=$fcity1["name"];	
	         				
	         					array_push($response1,array(                          		 
	         			 		"id"=>$roww['id'],                             		 		
      		          				"name"=>$roww['name'],
      		          				"gender"=>$roww['gender'],	
      		          				"birthday"=>$roww['birthday'],
      		          		 		"city"=>$city1,                     		 		    		          		          		          				          		
      		          				"profile_pic"=>$roww['profile_pic']	      		          		   				          		
		         				));
	         				}
         				}
         				
         				
         				
	         			
	         			/*
	         			$Qcitygetc=mysqli_query($con,$Qcity);
	         			$fcitygetc= mysqli_fetch_array($Qcitygetc); 
	         			$citycode=$fcitygetc["city"];	
	         		
	         			
	         		
	         			if($citycode)
	         			{	         			
	         			$Qscity1="Select * from cities where id='$citycode'";
	         			$rcity1=mysqli_query($con,$Qscity1);
	         			$fcity1= mysqli_fetch_array($rcity1); 
	         			$city1=$fcity1["name"];	
	         			}
	         		 	        		
	         			$resulta="SELECT tbl_user.id, tbl_user.name,  tbl_user.gender, tbl_user.birthday, tbl_user.profile_pic, tbl_userdetail.city FROM tbl_user INNER JOIN tbl_userdetail ON tbl_user.id = tbl_userdetail.user LIMIT 0,20";	     		
	         				     							
	         			
	         			
	         			$citycode1=$row['city'];
	         			$Qscity1="Select * from cities where id='$citycode1'";
	         			$rcity1=mysqli_query($con,$Qscity1);
	         			$fcity1= mysqli_fetch_array($rcity1); 
	         			$city1=$fcity1["name"];		*/         			         			
	         			       			
	         		
	         			    			
	         		
	        		}
	        		     

       			}
       			
       			echo json_encode($response1);
       			
       			  			
		}
		else
		{
		echo "o friend";
		
		}
		
		}
		else
		{
		
		echo "go in else";	
		
		}
	
	}	
	    	
    	}
    	else{
    	echo json_encode("post");
    	
    	}
?>
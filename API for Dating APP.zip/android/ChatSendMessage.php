<?php

if($_SERVER["REQUEST_METHOD"]=="POST")
{	
	include "config.php";	
	
	if(isset($_POST['GetOldChat']))    	
    	{	    		
    		$load1=$_POST['GetOldChat'];    		
    		$sendto=$_POST['sendto'];
    		$sendby=$_POST['sendby'];
    		$response1=array();		
		$resulta="SELECT id,senderid,recvrid,message,read_status,createdate from  tbl_msg where (senderid='$sendby' and recvrid='$sendto')or(senderid='$sendto' and recvrid='$sendby') ORDER BY id ASC";	
		$result1=mysqli_query($con,$resulta);			
		if(mysqli_num_rows($result1)>0){
		

         		while($row=mysqli_fetch_array($result1))
         		{
	         		if($row)
	         		{  			
	         			array_push($response1,array(                          		 
	         			 "id"=>$row['id'],                             		 		
      		          		"senderid"=>$row['senderid'],
      		          		"recvrid"=>$row['recvrid'],	
      		          		"message"=>$row['message'],
      		          		"read_status"=>$row['read_status'],
      		          		"createdate"=>$row['createdate']	      		          		   				          		
		         		));    			
	         		
	        		}	        		     

       			}
       			
       			echo json_encode($response1);  			
		}	
    	}
    	
    	if(isset($_POST['GetSendNewMsg']))    	
    	{	    		
    		$load1=$_POST['GetSendNewMsg'];        
        	$sendto=$_POST['sendto'];
        	$sendby=$_POST['sendby'];
        	$msg=$_POST['msg'];        	
    			$responsesss=array(); 	
		 	$addMessage="insert into tbl_msg (senderid,recvrid,message,read_status)VALUES('$sendby','$sendto','$msg','u')"; 
			if(mysqli_query($con,$addMessage))
			{
		
				echo "message sended";
		
			}
			else
			{
				echo "message not sended";
		
			}	
    	}
    	if(isset($_POST['Runtime']))    	
    	{	    		
    		$load1=$_POST['Runtime'];        
        	$sendto=$_POST['sendto'];
        	$sendby=$_POST['sendby'];       
        	$nextdta=$_POST['getnext'];  
    		
    		if($load1=="R")
    		{
    		 
    		$responseeeee=array();			
		
		
		$resulta="SELECT id,senderid,recvrid,message,read_status,createdate from  tbl_msg where (senderid='$sendby' and recvrid='$sendto')or(senderid='$sendto' and recvrid='$sendby') ORDER BY id ASC LIMIT $nextdta,20";
		
		$result1=mysqli_query($con,$resulta);			
		
		
		if(mysqli_num_rows($result1)>0){
		

         		while($rowe=mysqli_fetch_array($result1))
         		{
	         		if($rowe)
	         		{  			
	         			array_push($responseeeee,array(                          		 
	         			 "id"=>$rowe['id'],                             		 		
      		          		"senderid"=>$rowe['senderid'],
      		          		"recvrid"=>$rowe['recvrid'],	
      		          		"message"=>$rowe['message'],
      		          		"read_status"=>$rowe['read_status'],
      		          		"createdate"=>$rowe['createdate']	      		          		   				          		
		         		));    			
	         		
	        		}	        		     

       			}
       			
       			echo json_encode($responseeeee);  			
		}
		else
		{
		
		echo $nextdta."===".$sendto."===".$sendby;
		}
		}	
		else
		{
		echo '$nextdta';
		}
    	}
  }
?>
<?php
$username="brilligs_dating";
$password="dating@321";
$host="localhost";
$db_name="brilligs_dating";

$con=mysqli_connect($host,$username,$password,$db_name);

if(!$con)
{
	echo json_encode("Connection Failed Please Try Again !");
}
?>
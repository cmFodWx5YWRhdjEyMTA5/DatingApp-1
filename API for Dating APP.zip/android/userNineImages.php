<?php

if($_SERVER["REQUEST_METHOD"]=="POST")
{
	include "config.php";		
		
    	if($_POST['filetype']=='YesImage')
    	{
    		$upuserid=$_POST['userid'];
    		$upimage=$_POST['imagefile'];
    		$upimagename=$_POST['imageName'];
    		$upimageNumber=$_POST['imageNumber'];
    		
    		$path = "../img/photo/$upimagename.jpg";
    		
    		//$path = "profilephotos/$upuserid.jpg";
    		
    		$imgName=$upimagename.".jpg";
    		
    		
    			if($upimage)
    			{
    				$resu="select * from user_pics where user='$upuserid'"; 	   		
    		
				$result=mysqli_query($con,$resu);
		
				if(mysqli_num_rows($result)>0)
				{
				
					if($upimageNumber=="photo1")
					{
    			
    						if(file_put_contents($path,base64_decode($upimage)))
    						{
    							$sql="UPDATE user_pics SET photo1='$imgName' WHERE user=$upuserid";
    		
    							if (mysqli_query($con, $sql)) {
    		
    								echo $imgName;
    				
    							}
    		
    						}    				
    						else
    						{
    							echo "0";    		
    						}
    					}
    					else if($upimageNumber=="photo2")
					{
    			
    						if(file_put_contents($path,base64_decode($upimage)))
    						{
    							$sql="UPDATE user_pics SET photo2='$imgName' WHERE user=$upuserid";
    		
    							if (mysqli_query($con, $sql)) {
    		
    								echo $imgName;
    				
    							}
    		
    						}    				
    						else
    						{
    							echo "0";    		
    						}
    					}
    					else if($upimageNumber=="photo3")
					{
    			
    						if(file_put_contents($path,base64_decode($upimage)))
    						{
    							$sql="UPDATE user_pics SET photo3='$imgName' WHERE user=$upuserid";
    		
    							if (mysqli_query($con, $sql)) {
    		
    								echo $imgName;
    				
    							}
    		
    						}    				
    						else
    						{
    							echo "0";    		
    						}
    					}
    					else if($upimageNumber=="photo4")
					{
    			
    						if(file_put_contents($path,base64_decode($upimage)))
    						{
    							$sql="UPDATE user_pics SET photo4='$imgName' WHERE user=$upuserid";
    		
    							if (mysqli_query($con, $sql)) {
    		
    								echo $imgName;
    				
    							}
    		
    						}    				
    						else
    						{
    							echo "0";    		
    						}
    					}
    					else if($upimageNumber=="photo5")
					{
    			
    						if(file_put_contents($path,base64_decode($upimage)))
    						{
    							$sql="UPDATE user_pics SET photo5='$imgName' WHERE user=$upuserid";
    		
    							if (mysqli_query($con, $sql)) {
    		
    								echo $imgName;
    				
    							}
    		
    						}    				
    						else
    						{
    							echo "0";    		
    						}
    					}
    					else if($upimageNumber=="photo6")
					{
    			
    						if(file_put_contents($path,base64_decode($upimage)))
    						{
    							$sql="UPDATE user_pics SET photo6='$imgName' WHERE user=$upuserid";
    		
    							if (mysqli_query($con, $sql)) {
    		
    								echo $imgName;
    				
    							}
    		
    						}    				
    						else
    						{
    							echo "0";    		
    						}
    					}
    					else if($upimageNumber=="photo7")
					{
    			
    						if(file_put_contents($path,base64_decode($upimage)))
    						{
    							$sql="UPDATE user_pics SET photo7='$imgName' WHERE user=$upuserid";
    		
    							if (mysqli_query($con, $sql)) {
    		
    								echo $imgName;
    				
    							}
    		
    						}    				
    						else
    						{
    							echo "0";    		
    						}
    					}
    					else if($upimageNumber=="photo8")
					{
    			
    						if(file_put_contents($path,base64_decode($upimage)))
    						{
    							$sql="UPDATE user_pics SET photo8='$imgName' WHERE user=$upuserid";
    		
    							if (mysqli_query($con, $sql)) {
    		
    								echo $imgName;
    				
    							}
    		
    						}    				
    						else
    						{
    							echo "0";    		
    						}
    					}
    					else if($upimageNumber=="photo9")
					{
    			
    						if(file_put_contents($path,base64_decode($upimage)))
    						{
    							$sql="UPDATE user_pics SET photo9='$imgName' WHERE user=$upuserid";
    		
    							if (mysqli_query($con, $sql)) {
    		
    								echo $imgName;
    				
    							}
    		
    						}    				
    						else
    						{
    							echo "0";    		
    						}
    					}
    				}
    				else
    				{
    					if($upimageNumber=="photo1")
					{
    			
    						if(file_put_contents($path,base64_decode($upimage)))
    						{
    							$sql="Insert into user_pics(photo1,user)values('$imgName','$upuserid')";
    		
    							if (mysqli_query($con, $sql)) {
    		
    								echo "1";
    				
    							}
    		
    						}    				
    						else
    						{
    							echo "0";    		
    						}
    					}
    					else if($upimageNumber=="photo2")
					{
    			
    						if(file_put_contents($path,base64_decode($upimage)))
    						{
    							$sql="Insert into user_pics(photo2,user)values('$imgName','$upuserid')";
    		
    							if (mysqli_query($con, $sql)) {
    		
    								echo "1";
    				
    							}
    		
    						}    				
    						else
    						{
    							echo "0";    		
    						}
    					}
    					else if($upimageNumber=="photo3")
					{
    			
    						if(file_put_contents($path,base64_decode($upimage)))
    						{
    							$sql="Insert into user_pics(photo3,user)values('$imgName','$upuserid')";
    		
    							if (mysqli_query($con, $sql)) {
    		
    								echo "1";
    				
    							}
    		
    						}    				
    						else
    						{
    							echo "0";    		
    						}
    					}
    					else if($upimageNumber=="photo4")
					{
    			
    						if(file_put_contents($path,base64_decode($upimage)))
    						{
    							$sql="Insert into user_pics(photo4,user)values('$imgName','$upuserid')";
    		
    							if (mysqli_query($con, $sql)) {
    		
    								echo "1";
    				
    							}
    		
    						}    				
    						else
    						{
    							echo "0";    		
    						}
    					}
    					else if($upimageNumber=="photo5")
					{
    			
    						if(file_put_contents($path,base64_decode($upimage)))
    						{
    							$sql="Insert into user_pics(photo5,user)values('$imgName','$upuserid')";
    		
    							if (mysqli_query($con, $sql)) {
    		
    								echo "1";
    				
    							}
    		
    						}    				
    						else
    						{
    							echo "0";    		
    						}
    					}
    					else if($upimageNumber=="photo6")
					{
    			
    						if(file_put_contents($path,base64_decode($upimage)))
    						{
    							$sql="Insert into user_pics(photo6,user)values('$imgName','$upuserid')";
    		
    							if (mysqli_query($con, $sql)) {
    		
    								echo "1";
    				
    							}
    		
    						}    				
    						else
    						{
    							echo "0";    		
    						}
    					}
    					else if($upimageNumber=="photo7")
					{
    			
    						if(file_put_contents($path,base64_decode($upimage)))
    						{
    							$sql="Insert into user_pics(photo7,user)values('$imgName','$upuserid')";
    		
    							if (mysqli_query($con, $sql)) {
    		
    								echo "1";
    				
    							}
    		
    						}    				
    						else
    						{
    							echo "0";    		
    						}
    					}
    					else if($upimageNumber=="photo8")
					{
    			
    						if(file_put_contents($path,base64_decode($upimage)))
    						{
    							$sql="Insert into user_pics(photo8,user)values('$imgName','$upuserid')";
    		
    							if (mysqli_query($con, $sql)) {
    		
    								echo "1";
    				
    							}
    		
    						}    				
    						else
    						{
    							echo "0";    		
    						}
    					}
    					else if($upimageNumber=="photo9")
					{
    			
    						if(file_put_contents($path,base64_decode($upimage)))
    						{
    							$sql="Insert into user_pics(photo9,user)values('$imgName','$upuserid')";
    		
    							if (mysqli_query($con, $sql)) {
    		
    								echo "1";
    				
    							}
    		
    						}    				
    						else
    						{
    							echo "0";    		
    						}
    					}
    				
    				
    				}
    				
    			}
    			
    		
    		
    		
    	}
    	
    		
   
}


?>
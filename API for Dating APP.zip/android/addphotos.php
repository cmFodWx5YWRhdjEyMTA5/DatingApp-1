<?php

if($_SERVER["REQUEST_METHOD"]=="POST")
{
	include "config.php";		
	
	if(isset($_POST['UpdateMyProfile']))    
    		{  	
    		$upuserid=$_POST['upuserid'];
    		$upname=$_POST['upname'];
    		$uphone=$_POST['uphone'];
    		$updob=$_POST['updob'];
    		$upAbout=$_POST['upAbout'];
    		$upParents=$_POST['upParents'];
    		$upgender=$_POST['upgender'];
    		$upcountry=$_POST['upcountry'];
    		$upstate=$_POST['upstate'];
    		$upcity=$_POST['upcity'];
    		$uplookfor=$_POST['uplookfor'];
    		$uprelship=$_POST['uprelship'];
    		$upsmoke=$_POST['upsmoke'];    		
    		$updrink=$_POST['updrink'];
    		$upedu=$_POST['upedu'];
    		$uplang=$_POST['uplang'];
    		$upminage=$_POST['upminage'];
    		$upmaxage=$_POST['upmaxage'];
    		$upeyecolor=$_POST['upeyecolor'];
    		$upskincolor=$_POST['upskincolor'];
    		$upwork=$_POST['upwork'];
    		$upintrest=$_POST['upintrest'];   	
    		
    		
    		 		
    		$upLookRel=$_POST['upLookRel'];
    		
    		
		$upLookReltrim = substr(trim($upLookRel), 0, -1);
    		
    		
    		   		
    		
    		$countryQuery="select * from countries where name='$upcountry'";    		
    		$rconuntryquery=mysqli_query($con,$countryQuery);
    		$fcountryid= mysqli_fetch_array($rconuntryquery); 
    		$countryid=$fcountryid["id"];
    		
    		
    		  		
    		
    		$stateQuery="select * from states where name='$upstate'";    		
    		$rstatequery=mysqli_query($con,$stateQuery);
    		$fstateid= mysqli_fetch_array($rstatequery); 
    		$stateid=$fstateid["id"];
    		
    		
    		$cityQuery="select * from cities where name='$upcity'";    		
    		$rcityquery=mysqli_query($con,$cityQuery);
    		$fcityid= mysqli_fetch_array($rcityquery); 
    		$cityid=$fcityid["id"];
    		
    		$resulta="UPDATE  tbl_user INNER JOIN tbl_userdetail ON (tbl_user.id=tbl_userdetail.user)
SET tbl_user.name='$upname',tbl_user.phone='$uphone',tbl_user.gender='$upgender',tbl_user.birthday='$updob',tbl_userdetail.country='$countryid',tbl_userdetail.state='$stateid',tbl_userdetail.city='$cityid',tbl_userdetail.looking='$uplookfor',tbl_userdetail.rel_status='$uprelship',tbl_userdetail.smoke='$upsmoke',tbl_userdetail.drink='$updrink',tbl_userdetail.education='$upedu',tbl_userdetail.language='$uplang',tbl_userdetail.minage='$upminage',tbl_userdetail.maxage='$upmaxage',tbl_userdetail.eye='$upeyecolor',tbl_userdetail.skin='$upskincolor',tbl_userdetail.work='$upwork',tbl_userdetail.interest='$upintrest',tbl_userdetail.	look_rel='$upLookReltrim',tbl_userdetail.about='$upAbout',tbl_userdetail.partner='$upParents'
WHERE tbl_user.id='$upuserid'"; 	  
    		
    		
    		if (mysqli_query($con, $resulta)) {
    			echo "1,".$countryid. "," . $stateid.",".$cityid;
		} 
		else {
    			echo "0" . mysqli_error($con);
		}
    		
    		
    		
    		
    		
    		
    		
		
		
		
	}
	
	
	if(isset($_POST['SubmitProfileDta']))    
    		{  	
    		$upuserid=$_POST['upuserid'];
    		$upname=$_POST['upname'];
    		$uphone=$_POST['uphone'];
    		$updob=$_POST['updob'];
    		$upAbout=$_POST['upAbout'];
    		$upParents=$_POST['upParents'];
    		$upgender=$_POST['upgender'];
    		$upcountry=$_POST['upcountry'];
    		$upstate=$_POST['upstate'];
    		$upcity=$_POST['upcity'];
    		$uplookfor=$_POST['uplookfor'];
    		$uprelship=$_POST['uprelship'];
    		$upsmoke=$_POST['upsmoke'];    		
    		$updrink=$_POST['updrink'];
    		$upedu=$_POST['upedu'];
    		$uplang=$_POST['uplang'];
    		$upminage=$_POST['upminage'];
    		$upmaxage=$_POST['upmaxage'];
    		$upeyecolor=$_POST['upeyecolor'];
    		$upskincolor=$_POST['upskincolor'];
    		$upwork=$_POST['upwork'];
    		$upintrest=$_POST['upintrest'];     		
    		
    		 		
    		$upLookRel=$_POST['upLookRel'];
    		
    		
		$upLookReltrim = substr(trim($upLookRel), 0, -1);
    		
    		
    		   		
    		
    		$countryQuery="select * from countries where name='$upcountry'";    		
    		$rconuntryquery=mysqli_query($con,$countryQuery);
    		$fcountryid= mysqli_fetch_array($rconuntryquery); 
    		$countryid=$fcountryid["id"];
    		
    		
    		  		
    		
    		$stateQuery="select * from states where name='$upstate'";    		
    		$rstatequery=mysqli_query($con,$stateQuery);
    		$fstateid= mysqli_fetch_array($rstatequery); 
    		$stateid=$fstateid["id"];
    		
    		
    		$cityQuery="select * from cities where name='$upcity'";    		
    		$rcityquery=mysqli_query($con,$cityQuery);
    		$fcityid= mysqli_fetch_array($rcityquery); 
    		$cityid=$fcityid["id"];
    		
    			 
    		  		
    		$resulta="UPDATE  tbl_user 
SET name='$upname',phone='$uphone',gender='$upgender',birthday='$updob'
WHERE id='$upuserid'"; 	  
    		 	  	
    		
    		
    		if (mysqli_query($con, $resulta)) {
    			$insDtl	="insert into tbl_userdetail(country,state,city,looking,rel_status,smoke,drink,education,language,minage,maxage,eye,skin,work,interest,look_rel,about,partner,user)values('$countryid','$stateid','$cityid','$uplookfor','$uprelship','$upsmoke','$updrink','$upedu','$uplang','$upminage','$upmaxage','$upeyecolor','$upskincolor','$upwork','$upintrest','$upLookReltrim','$upAbout','$upParents','$upuserid')";
    		
    			if (mysqli_query($con, $insDtl	))
    			{
    				$resr="UPDATE  tbl_user SET reg_status=2 WHERE id='$upuserid'"; 
    			
    				if (mysqli_query($con, $resr))
    				{
    					echo "updateDtl";
    				}
    			
    				
    			}
    		else
    		{
    		echo "notupdateDtl".$upuserid;
    		
    		
    		}
    		
    		
		} 
		else {
    			echo "0" . mysqli_error($con);
		}
    		
    		
    		
    		
    		
    		
    		
		
		
		
	}
	
	
	
	
	
if(isset($_POST['filetype']))    
   { 
   
   	if($_POST['filetype']=="YesImage")
    	{
    		$upuserid=$_POST['userid'];
    		$upimage=$_POST['imagefile'];
    		$upimagename=$_POST['imageName'];
    		
    		$path = "../img/members/$upimagename.jpg";
    		
    		//$path = "profilephotos/$upuserid.jpg";
    		
    		$imgName=$upimagename.".jpg";
    		
    		
    		
    			if($upimage)
    			{
    				if(file_put_contents($path,base64_decode($upimage)))
    				{
    				
    					$sql="UPDATE tbl_user SET profile_pic ='$imgName' WHERE id=$upuserid";
    		
    					if (mysqli_query($con, $sql)) {
    		
    						echo "1";
    					
    					}
    		
    				}
    				
    				else
    				{
    					echo "0";
    		
    				}
    			}
    			
    		
    		
    		
    	}
    	if($_POST['filetype']=='YesCover')
    	{
    		$upuserid=$_POST['userid'];
    		$upimage=$_POST['imagefile'];
    		$upimagename=$_POST['imageName'];
    		
    		$path = "../img/cover/$upimagename.jpg";
    		
    		//$path = "profilephotos/$upuserid.jpg";
    		
    		$imgName=$upimagename.".jpg";
    		
    		
    		
    			if($upimage)
    			{
    				if(file_put_contents($path,base64_decode($upimage)))
    				{
    				
    					$sql="UPDATE tbl_user SET cover_pic='$imgName' WHERE id=$upuserid";
    		
    					if (mysqli_query($con, $sql)) {
    		
    						echo "1";
    					
    					}
    		
    				}
    				
    				else
    				{
    					echo "0";
    		
    				}
    			}
    			
    		
    		
    		
    	}
    	
    		
   }
}


?>
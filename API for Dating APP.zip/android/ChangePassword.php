<?php

if($_SERVER["REQUEST_METHOD"]=="POST")
{
	include "config.php";	
	
	
	if(isset($_POST['ChangePass']))    
    	{	
    		
    		$userid = $_POST['userid'];
    		$oldpass = $_POST['OldPassword'];
    		$newpass = $_POST['NewPassword'];	
		
    	
    		$resulta="select password from tbl_user where id='$userid'"; 	   		
    		
    		    		
    		$qpass=mysqli_query($con,$resulta);
    		$fpass= mysqli_fetch_array($qpass); 
    		$opass=$fpass["password"];
    		
    		
    		
    		if($opass==$oldpass)
    		{	

		$changePass="update tbl_user set password='$newpass' where id='$userid'";

			if (mysqli_query($con, $changePass)) {
    				echo "password Changed";
			} 
			else {
    				echo "Try again!";
			}
				
		
		}
		else
		{
			
			echo "Wrong Password".$opass ."new pass-".$newpass."userid=".$userid;	
		
		}
		
	
		
}


}

?>
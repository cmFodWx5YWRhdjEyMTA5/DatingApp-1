<?php

if($_SERVER["REQUEST_METHOD"]=="POST")
{	
	include "config.php";	
	
	if(isset($_POST['GetViewMessage']))    	
    	{	
    		$load1=$_POST['GetViewMessage']; 
    		$userid=$_POST['userid'];
    		$senderid=$_POST['senderid'];
    		$receiverid=$_POST['receiverid'];  		
    		
    		
    		if($load1=="1")
    		{ 
    		
    		$resulta="SELECT sender,receiver,message,action FROM tbl_message where (sender='$senderid' AND receiver='$receiverid') or (sender='$receiverid' AND receiver='$senderid')";
    		    		
    			
    		
    		$response1=array();
    		/*$resulta="SELECT tbl_user.id, tbl_user.name,  tbl_user.gender, tbl_user.birthday, tbl_user.profile_pic FROM tbl_friends INNER JOIN tbl_user ON tbl_friends.friend= tbl_user.id where tbl_friends.user='$currentuser' or tbl_friends.friend='$currentuser' LIMIT 0,20";	  */   		
		
		//$end=mysql_num_rows($resulta);
		
		
		$result1=mysqli_query($con,$resulta);	
		
		
			if(mysqli_num_rows($result1)>0){			
					

         			while($row=mysqli_fetch_array($result1))
         			{
         				
         				$rec=$row['receiver'];
         				$send=$row['sender'];
         				$msg=$row['message'];
         				$sendorrecd="";
         					
         					if($rec==$userid)
         					{
         					
         					$sendorrecd="send";
         					$resu1="SELECT id,name,gender,birthday,profile_pic FROM tbl_user where id='$send'";
         					
         					$rresu1=mysqli_query($con,$resu1);
	         				$frresu1= mysqli_fetch_array($rresu1); 
	         				$idf=$frresu1["id"];
	         				$namef=$frresu1["name"];
	         				$genderf=$frresu1["gender"];
	         				$birthdayf=$frresu1["birthday"];
	         				$profile_picf=$frresu1["profile_pic"];  
	         				
         					
         					}
         					else
         					{
         					$sendorrecd="receive";
         					$resu1="SELECT id,name,gender,birthday,profile_pic FROM tbl_user where id='$rec'";
         					
         					$rresu1=mysqli_query($con,$resu1);
	         				$frresu1= mysqli_fetch_array($rresu1); 
	         				$idf=$frresu1["id"];
	         				$namef=$frresu1["name"];
	         				$genderf=$frresu1["gender"];
	         				$birthdayf=$frresu1["birthday"];
	         				$profile_picf=$frresu1["profile_pic"];           				
         					
         					
         					}
         				      				
         				      				         			
	         			
	         			
	         			array_push($response1,array(   		 
	       				"name"=>$namef,
      		          		"gender"=>$genderf,	
      		          		"birthday"=>$birthdayf,      		          		                    		 		    		          		          		          				          		
      		          		"profile_pic"=>$profile_picf,
      		          		"reciver"=>$rec,     		          			          		                    		 		    		          		          		          				          		
      		          		"sender"=>$send,
      		          		"message"=>$msg,
      		          		"SendOrRec"=>$sendorrecd      	          		                    		 		    		          		          		          				          		
      		          		
      		          		    		          		   				          		
		         		));            				
         			}
         			echo json_encode($response1);
         			
         			
         			
         			
         			
         		
         		
         		}
         		else
         		{
         		echo "no row";
         		
         		
         		}
    		
    		}
    		else
    		{
    		echo "else";
    		}
    		
		
	

	}
	

	
	}
	
    	
    	
?>
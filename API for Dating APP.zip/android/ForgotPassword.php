<?php
include "config.php";	
	
if(isset($_POST['Email'])){
	//$email=mysqli_real_escape_string($_POST['Email']);
	$email=$_POST['Email'];
		$quer1=mysqli_query($con,"select * from tbl_user where email='$email'");
		if(mysqli_num_rows($quer1)>0){
		$fetch1=mysqli_fetch_array($quer1);
		$passw=$fetch1['password'];
		$from="Brill Dating - Best Dating Website In India<info@bdating.in>";
                $bcc=$email;
                $to = "info@brilldating.com";
                $subject = "Forgot Password -Bdating ";
                $htmlcontent="<table><tr><td>Hi ! </td></tr><tr><td> Greetings from Brill Dating </td></tr><tr><td> Your login authentications are as follows :- </td></tr><tr><td> Email : - :".$email."</td></tr><tr><td>Password : - ".$passw."</td></tr><tr><td>Thank You !</td></tr><tr><td>Team Brill Dating</td></tr></table>";          
$headers = 'MIME-Version: 1.0' . "\r\n";
$headers .='Content-type:text/html;charset=UTF-8' . "\r\n";
$headers .='From:'.$from."\r\n";
//$headers .='Bcc: '. $bcc ."\r\n";
$headers .= "\r\n";
 $retval = mail ($bcc,$subject,$htmlcontent,$headers);
 
 echo "Check your email";
 
}
else{
echo "Email Not Found";
}
}
?>
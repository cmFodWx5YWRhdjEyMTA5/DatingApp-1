<?php

if($_SERVER["REQUEST_METHOD"]=="POST")
{	
	include "config.php";	
	
	// friend request sended
	
	if(isset($_POST['GetAllFriendReqsend']))    	
    	{	
    		$load1=$_POST['GetAllFriendReqsend']; 
    		$currentuser=$_POST['cuserid'];  	
    		
    		
    		
    		if($load1=="1")
    		{     			
    		
    		$response1=array();
    		$resulta="SELECT tbl_user.id, tbl_user.name,  tbl_user.gender, tbl_user.birthday, tbl_user.profile_pic,tbl_friendrequests.user,tbl_friendrequests.receiver FROM tbl_friendrequests INNER JOIN tbl_user ON tbl_friendrequests.receiver= tbl_user.id where tbl_friendrequests.user='$currentuser' LIMIT 0,20";    		
		
		//$end=mysql_num_rows($resulta);
		
		
		$result1=mysqli_query($con,$resulta);	
		
		
			if(mysqli_num_rows($result1)>0){
			
					

         			while($row=mysqli_fetch_array($result1))
         			{
         			
         				$uid=$row['id'];
         			
         				$Qcitycode1="Select city from tbl_userdetail where user='$uid'";
         				$rcitycode1=mysqli_query($con,$Qcitycode1);
	         			$fcitycode= mysqli_fetch_array($rcitycode1); 
	         			$city1=$fcitycode["city"];	
         				
         				
	         			$Qscity1="Select * from cities where id='$city1'";
	         			$rcity1=mysqli_query($con,$Qscity1);
	         			$fcity1= mysqli_fetch_array($rcity1); 
	         			$city2=$fcity1["name"];	
	         			
	         			
	         			
	         			array_push($response1,array(                          		 
	         			 "id"=>$row['id'],                             		 		
      		          		"name"=>$row['name'],
      		          		"gender"=>$row['gender'],	
      		          		"birthday"=>$row['birthday'],      		          		                    		 		    		          		          		          				          		
      		          		"profile_pic"=>$row['profile_pic'],
      		          		 "city"=>$city2      		          		   				          		
		         		));            				
         			}
         			
         			echo json_encode($response1);
         			
         			
         			
         			
         		
         		
         		}
         		else
			{
				echo "You Have No Friend Request";
			
			}
    		
    		}
    		else
    		{
    		echo "else";
    		}
    		
		
	

	}
	
	else if(isset($_POST['moredtasend']))    	
    	{		
    		$load1=$_POST['moredtasend']; 
    		$currentuser=$_POST['cuserid'];  
    		$next=$_POST['mored'];     	
    		
    		 		
    		
    		
    		$response=array();
    		
    		if($load1=="more")
    		{
		
		
		$resultb="SELECT tbl_user.id, tbl_user.name,  tbl_user.gender, tbl_user.birthday, tbl_user.profile_pic,tbl_friendrequests.user,tbl_friendrequests.receiver FROM tbl_friendrequests INNER JOIN tbl_user ON tbl_friendrequests.receiver= tbl_user.id where tbl_friendrequests.user='$currentuser' LIMIT $next,20";
		
		
		
		$result=mysqli_query($con,$resultb);	
		
		if(mysqli_num_rows($result)>0){
		

         		while($row=mysqli_fetch_array($result))
         			{
         				$uid=$row['id'];
         			
         				$Qcitycode1="Select city from tbl_userdetail where user='$uid'";
         				$rcitycode1=mysqli_query($con,$Qcitycode1);
	         			$fcitycode= mysqli_fetch_array($rcitycode1); 
	         			$city1=$fcitycode["city"];	
         				
         				
	         			$Qscity1="Select * from cities where id='$city1'";
	         			$rcity1=mysqli_query($con,$Qscity1);
	         			$fcity1= mysqli_fetch_array($rcity1); 
	         			$city2=$fcity1["name"];	
	         			
	         			
	         			
	         			array_push($response,array(                          		 
	         			 "id"=>$row['id'],                             		 		
      		          		"name"=>$row['name'],
      		          		"gender"=>$row['gender'],	
      		          		"birthday"=>$row['birthday'],      		          		                    		 		    		          		          		          				          		
      		          		"profile_pic"=>$row['profile_pic'],
      		          		 "city"=>$city2      		          		   				          		
		         		)); 
         				
         			}
       			
       			//echo $mi;  
       			
       			echo json_encode($response);  			
		}
		else
		{
			echo "You Have No Friend Request";
		
		}
		
		}
		else
		{
		
		echo "go in else";	
		
		}
	
	}
	
	
	//Friendrequest received========
	
	else if(isset($_POST['GetAllFriendReq']))    	
    	{	
    		$load1=$_POST['GetAllFriendReq']; 
    		$currentuser=$_POST['cuserid'];  	
    		
    		
    		
    		if($load1=="1")
    		{     			
    		
    		$response1=array();
    		$resulta="SELECT tbl_user.id, tbl_user.name,  tbl_user.gender, tbl_user.birthday, tbl_user.profile_pic,tbl_friendrequests.user,tbl_friendrequests.receiver FROM tbl_friendrequests INNER JOIN tbl_user ON tbl_friendrequests.user= tbl_user.id where tbl_friendrequests.receiver='$currentuser' LIMIT 0,20";	     		
		
		//$end=mysql_num_rows($resulta);
		
		
		$result1=mysqli_query($con,$resulta);	
		
		
			if(mysqli_num_rows($result1)>0){
			
					

         			while($row=mysqli_fetch_array($result1))
         			{
         			
         				$uid=$row['id'];
         			
         				$Qcitycode1="Select city from tbl_userdetail where user='$uid'";
         				$rcitycode1=mysqli_query($con,$Qcitycode1);
	         			$fcitycode= mysqli_fetch_array($rcitycode1); 
	         			$city1=$fcitycode["city"];	
         				
         				
	         			$Qscity1="Select * from cities where id='$city1'";
	         			$rcity1=mysqli_query($con,$Qscity1);
	         			$fcity1= mysqli_fetch_array($rcity1); 
	         			$city2=$fcity1["name"];	
	         			
	         			
	         			
	         			array_push($response1,array(                          		 
	         			 "id"=>$row['id'],                             		 		
      		          		"name"=>$row['name'],
      		          		"gender"=>$row['gender'],	
      		          		"birthday"=>$row['birthday'],      		          		                    		 		    		          		          		          				          		
      		          		"profile_pic"=>$row['profile_pic'],
      		          		 "city"=>$city2      		          		   				          		
		         		));            				
         			}
         			
         			echo json_encode($response1);
         			
         			
         			
         			
         		
         		
         		}
         		else
			{
				echo "You Have No Friend Request";
			
			}
    		
    		}
    		else
    		{
    		echo "else";
    		}
    		
		
	

	}
	
 	else if(isset($_POST['moredta']))    	
    	{		
    		$load1=$_POST['moredta']; 
    		$currentuser=$_POST['cuserid'];  
    		$next=$_POST['next'];     	
    		
    		 		
    		
    		
    		$response=array();
    		
    		if($load1=="more")
    		{
		
		
		$resultb="SELECT tbl_user.id, tbl_user.name,  tbl_user.gender, tbl_user.birthday, tbl_user.profile_pic,tbl_friendrequests.user,tbl_friendrequests.receiver FROM tbl_friendrequests INNER JOIN tbl_user ON tbl_friendrequests.receiver= tbl_user.id where tbl_friendrequests.user='$currentuser' LIMIT 0,20";
		
		
		
		$result=mysqli_query($con,$resultb);	
		
		if(mysqli_num_rows($result)>0){
		

         		while($row=mysqli_fetch_array($result))
         			{
         				$uid=$row['id'];
         			
         				$Qcitycode1="Select city from tbl_userdetail where user='$uid'";
         				$rcitycode1=mysqli_query($con,$Qcitycode1);
	         			$fcitycode= mysqli_fetch_array($rcitycode1); 
	         			$city1=$fcitycode["city"];	
         				
         				
	         			$Qscity1="Select * from cities where id='$city1'";
	         			$rcity1=mysqli_query($con,$Qscity1);
	         			$fcity1= mysqli_fetch_array($rcity1); 
	         			$city2=$fcity1["name"];	
	         			
	         			
	         			
	         			array_push($response,array(                          		 
	         			 "id"=>$row['id'],                             		 		
      		          		"name"=>$row['name'],
      		          		"gender"=>$row['gender'],	
      		          		"birthday"=>$row['birthday'],      		          		                    		 		    		          		          		          				          		
      		          		"profile_pic"=>$row['profile_pic'],
      		          		 "city"=>$city2      		          		   				          		
		         		)); 
         				
         			}
       			
       			//echo $mi;  
       			
       			echo json_encode($response);  			
		}
		else
		{
			echo "You Have No Friend Request";
		
		}
		
		}
		else
		{
		
		echo "go in else";	
		
		}
	
	}
	else
	{
	echo "Not Found ";	
	
	}
	
	
	
	
    	}
    	
?>
<?php

if($_SERVER["REQUEST_METHOD"]=="POST")
{	
	include "config.php";	
	
	if(isset($_POST['GetAllUser']))    	
    	{	
    		$load1=$_POST['GetAllUser'];   		
    		
    		
    		if($load1=="1")
    		{
    		$limit1=$_POST['limit'];  
    		$response1=array();
		
		
		$resulta="SELECT * from tbl_user LIMIT 0,20";
		
		$end=mysql_num_rows($resulta);
		
		
		$result1=mysqli_query($con,$resulta);	
		
		
		if(mysqli_num_rows($result1)>0){
		

         		while($row=mysqli_fetch_array($result1))
         		{
	         		if($row)
	         		{  
	         			$city1="";
	         			$Looking="";
	         			$Min="";
	         			$Max="";	         			
	         			
	         		
	         			$userid=$row['id'];
	         			$Qcity="Select city,looking,minage,maxage from  tbl_userdetail where user='$userid'";
	         			$Qcitygetc=mysqli_query($con,$Qcity);
	         			$fcitygetc= mysqli_fetch_array($Qcitygetc); 
	         			$citycode=$fcitygetc["city"];	
	         			
	         			
	         			
	         		
	         			if($citycode)
	         			{	         			
	         			$Qscity1="Select * from cities where id='$citycode'";
	         			$rcity1=mysqli_query($con,$Qscity1);
	         			$fcity1= mysqli_fetch_array($rcity1); 
	         			$city1=$fcity1["name"];	
	         			}
	         			
	         			$alFriend="";
	         			
	         			$countryQuery="select * from tbl_friends where user='$cuserid' and friend='$userid'";    		
    				if(mysqli_query($con,$countryQuery))
    				{
    					$alFriend="ALFriend";
    			
    				}
	         			
	         			
	         			
	         		 	        		
	         			/*$resulta="SELECT tbl_user.id, tbl_user.name,  tbl_user.gender, tbl_user.birthday, tbl_user.profile_pic, tbl_userdetail.city FROM tbl_user INNER JOIN tbl_userdetail ON tbl_user.id = tbl_userdetail.user LIMIT 0,20";	     		
	         				     							
	         			
	         			
	         			$citycode1=$row['city'];
	         			$Qscity1="Select * from cities where id='$citycode1'";
	         			$rcity1=mysqli_query($con,$Qscity1);
	         			$fcity1= mysqli_fetch_array($rcity1); 
	         			$city1=$fcity1["name"];		 */        			         			
	         			       			
	         		
	         			array_push($response1,array(                          		 
	         			 "id"=>$row['id'],                             		 		
      		          		"name"=>$row['name'],
      		          		"gender"=>$row['gender'],	
      		          		"birthday"=>$row['birthday'],
      		          		 "city"=>$city1,                     		 		    		          		          		          				          		
      		          		"profile_pic"=>$row['profile_pic']
      		          		
      		          		
      		          		
      		          		
      		          			      		          		   				          		
		         		));    			
	         		
	        		}
	        		     

       			}
       			
       			echo json_encode($response1);  			
		}
		else
		{
		echo "o row";
		
		}
		
		}
		else
		{
		
		echo "go in else";	
		
		}
	

	}
	
	
	if(isset($_POST['GetFilterdata']))    	
    	{	
    		$load1=$_POST['GetFilterdata'];  
    		$getSeek=$_POST['Getseeking'];  
    		$getFrom=$_POST['Getfrom'];  
    		$getTo=$_POST['Getto'];   		
    		
    		
    		if($load1=="1")
    		{
    		 
    		$response1=array();
		
		
		$resulta="SELECT * 
FROM tbl_userdetail
WHERE looking = '$getSeek'
AND (
minage >='$getFrom'
AND maxage <='$getTo'
)";
		
		$end=mysql_num_rows($resulta);
		
		
		$result1=mysqli_query($con,$resulta);	
		
		
		if(mysqli_num_rows($result1)>0){
		

         		while($row=mysqli_fetch_array($result1))
         		{
	         		if($row)
	         		{  
	         			$city1="";
	         			$Looking="";
	         			$Min="";
	         			$Max="";	         			
	         			
	         			
	         			
	         		
	         			$userid=$row['user'];
	         			$userdtl="Select id,name,gender,birthday,profile_pic,cover_pic from tbl_user where id='$userid'";
	         			$ruserdtl=mysqli_query($con,$userdtl);
	         			$fuserdtl= mysqli_fetch_array($ruserdtl); 	         			
	         			$uname=$fuserdtl["name"];
	         			$ugender=$fuserdtl["gender"];
	         			$ubday=$fuserdtl["birthday"];
	         			$upic=$fuserdtl["profile_pic"];	         			
	         			$citycode= $row['city'];            			
	         		
	         			if($citycode)
	         			{	         			
	         			$Qscity1="Select * from cities where id='$citycode'";
	         			$rcity1=mysqli_query($con,$Qscity1);
	         			$fcity1= mysqli_fetch_array($rcity1); 
	         			$city1=$fcity1["name"];	
	         			}
	         			
	         			    			         			
	         			       			
	         		
	         			array_push($response1,array(                          		 
	         			 "id"=>$row['user'],                             		 		
      		          		"name"=>$uname,
      		          		"gender"=>$ugender,	
      		          		"birthday"=>$ubday,
      		          		 "city"=>$city1,                     		 		    		          		          		          				          		
      		          		"profile_pic"=>$upic
      		          		     		          		    		          		    		          		
      		          		    		          		
      		          		
      		          		
      		          		
      		          		
      		          			      		          		   				          		
		         		));    			
	         		
	        		}
	        		     

       			}
       			
       			echo json_encode($response1);  			
		}
		else
		{
		echo "o row";
		
		}
		
		}
		else
		{
		
		echo "go in else";	
		
		}
	

	}
	
	
	
	if(isset($_POST['GetAdvanceFilterdata']))    	
    	{	
    		$load1=$_POST['GetAdvanceFilterdata'];  
    		$Getscountry=$_POST['Getscountry'];  
    		$Getsstate=$_POST['Getsstate'];  
    		$Getscity=$_POST['Getscity'];  
    		$Getminage=$_POST['Getminage'];  
    		$Getmaxage=$_POST['Getmaxage'];  
    		$Getseeking=$_POST['Getseeking'];  
    		
    		$Getupopenrel=$_POST['Getupopenrel'];  
    		$Getuplivein=$_POST['Getuplivein'];  
    		$Getuponenight=$_POST['Getuponenight'];  
    		$Getupfriendship=$_POST['Getupfriendship'];  
    		$Getuponlydating=$_POST['Getuponlydating'];  
    		$Getupfood=$_POST['Getupfood'];  
    		$Getuplongterm=$_POST['Getuplongterm'];  
    		$Getupparty=$_POST['Getupparty'];  
    		$Getuphiking=$_POST['Getuphiking'];      		
    		$Getupsecmarrage=$_POST['Getupsecmarrage'];  
    		$Getupmovie=$_POST['Getupmovie'];  
    		$Getuptea=$_POST['Getuptea'];   		
    		
    		
    		
    		
    		
    		
    		
    		
    		if($load1=="1")
    		{
    		 
    		$response1=array();
    		
    		
    		$countryQuery="select * from countries where name='$Getscountry'";    		
    		$rconuntryquery=mysqli_query($con,$countryQuery);
    		$fcountryid= mysqli_fetch_array($rconuntryquery); 
    		$countryid=$fcountryid["id"];
    		
    		
    		  		
    		
    		$stateQuery="select * from states where name='$Getsstate'";    		
    		$rstatequery=mysqli_query($con,$stateQuery);
    		$fstateid= mysqli_fetch_array($rstatequery); 
    		$stateid=$fstateid["id"];
    		
    		
    		$cityQuery="select * from cities where name='$Getscity'";    		
    		$rcityquery=mysqli_query($con,$cityQuery);
    		$fcityid= mysqli_fetch_array($rcityquery); 
    		$cityid=$fcityid["id"];
    		
    		
    		
    		
    		$opn='%'.$Getupopenrel.'%';
    		$live='%'.$Getuplivein.'%';
		
		
		$resulta="SELECT * 
FROM tbl_userdetail
WHERE looking = '$Getseeking'
AND country='$countryid' AND state='$stateid' AND city='$cityid' AND (
minage >='$Getminage'
AND maxage <='$Getmaxage'
) AND (look_rel LIKE '$opn' OR look_rel LIKE '$live')";



		
		$end=mysql_num_rows($resulta);
		
		
		$result1=mysqli_query($con,$resulta);	
		
		
		if(mysqli_num_rows($result1)>0){
		

         		while($row=mysqli_fetch_array($result1))
         		{
	         		if($row)
	         		{  
	         			$city1="";
	         			$Looking="";
	         			$Min="";
	         			$Max="";	         			
	         			
	         			
	         			
	         		
	         			$userid=$row['user'];
	         			$userdtl="Select id,name,gender,birthday,profile_pic,cover_pic from tbl_user where id='$userid'";
	         			$ruserdtl=mysqli_query($con,$userdtl);
	         			$fuserdtl= mysqli_fetch_array($ruserdtl); 	         			
	         			$uname=$fuserdtl["name"];
	         			$ugender=$fuserdtl["gender"];
	         			$ubday=$fuserdtl["birthday"];
	         			$upic=$fuserdtl["profile_pic"];	         			
	         			$citycode= $row['city'];            			
	         		
	         			if($citycode)
	         			{	         			
	         			$Qscity1="Select * from cities where id='$citycode'";
	         			$rcity1=mysqli_query($con,$Qscity1);
	         			$fcity1= mysqli_fetch_array($rcity1); 
	         			$city1=$fcity1["name"];	
	         			}
	         			
	         			    			         			
	         			       			
	         		
	         			array_push($response1,array(                          		 
	         			 "id"=>$row['user'],                             		 		
      		          		"name"=>$uname,
      		          		"gender"=>$ugender,	
      		          		"birthday"=>$ubday,
      		          		 "city"=>$city1,                     		 		    		          		          		          				          		
      		          		"profile_pic"=>$upic    		     		          		    		          		    		          		
      		          		    		          		
      		          		
      		          		
      		          		
      		          		
      		          			      		          		   				          		
		         		));    			
	         		
	        		}
	        		     

       			}
       			
       			echo json_encode($response1);  			
		}
		else
		{
		echo $opn;
		
		}
		
		}
		else
		{
		
		echo "go in else";	
		
		}
	

	}
	
	
	if(isset($_POST['moredta']))    	
    	{		
    		$load=$_POST['moredta'];
    		$mi=$_POST['mored'];   		
    		
    		
    		$response=array();
    		
    		if($load=="more")
    		{
		
		
		$resultb="SELECT * from tbl_user LIMIT $mi,20";
		
		
		
		$result=mysqli_query($con,$resultb);	
		
		if(mysqli_num_rows($result)>0){
		

         		while($row=mysqli_fetch_array($result))
         		{
	         		if($row)
	         		{   	        		
	         			$userid=$row['id'];
	         			$Qcity="Select city from  tbl_userdetail where user='$userid'";
	         			$Qcitygetc=mysqli_query($con,$Qcity);
	         			$fcitygetc= mysqli_fetch_array($Qcitygetc); 
	         			$citycode=$fcitygetc["city"];	
	         		
	         			$city1="";
	         		
	         			if($citycode!=0)
	         			{	         			
	         			$Qscity1="Select name from cities where id='$citycode'";
	         			$rcity1=mysqli_query($con,$Qscity1);
	         			$fcity1= mysqli_fetch_array($rcity1); 
	         			$city1=$fcity1["name"];	
	         			}
	         		 	        		
	         			/*$resulta="SELECT tbl_user.id, tbl_user.name,  tbl_user.gender, tbl_user.birthday, tbl_user.profile_pic, tbl_userdetail.city FROM tbl_user INNER JOIN tbl_userdetail ON tbl_user.id = tbl_userdetail.user LIMIT 0,20";	     		
	         				     							
	         			
	         			
	         			$citycode1=$row['city'];
	         			$Qscity1="Select * from cities where id='$citycode1'";
	         			$rcity1=mysqli_query($con,$Qscity1);
	         			$fcity1= mysqli_fetch_array($rcity1); 
	         			$city1=$fcity1["name"];		 */        			         			
	         			       			
	         		
	         			array_push($response,array(                          		 
	         			 "id"=>$row['id'],                             		 		
      		          		"name"=>$row['name'],
      		          		"gender"=>$row['gender'],	
      		          		"birthday"=>$row['birthday'],
      		          		 "city"=>$city1,                     		 		    		          		          		          				          		
      		          		"profile_pic"=>$row['profile_pic']	      		          		   				          		
		         		));    			
	         		
	        		}
	        		     

       			}
       			
       			//echo $mi;  
       			
       			echo json_encode($response);  			
		}
		else
		{
			echo "no more user";
		
		}
		
		}
		else
		{
		
		echo "go in else";	
		
		}
	
	}	
	    	
    	}
    	else{
    	echo json_encode("post");
    	
    	}
?>
<?php

if($_SERVER["REQUEST_METHOD"]=="POST")
{


			
		include "config.php";	
	
		$userid=$_POST['id'];
    		$subject= $_POST['title'];
    		$issue= $_POST['message'];
    		
    		
    	
		date_default_timezone_set("asia/kolkata");
		
		$date = date('Y-m-d');
		
			$resulta="insert into tbl_complaint(user,subject,complaint,compdate,remark,new,status)VALUES($userid,'$subject','$issue','$date','yes',1,1)";	   		
    		
    			

		if(mysqli_query($con,$resulta))
		{
			echo "complaint sended sucessfully";
			
			
		
		}
		else
		{
			echo "try again";
		
		}
		
			
		
			
		
    	
    
}

?>
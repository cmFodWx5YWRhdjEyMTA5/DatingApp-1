<?php

if($_SERVER["REQUEST_METHOD"]=="POST")
{
	include "config.php";		
	
	
	if(isset($_POST['CreateAccount']))    
    	{	
    		
    		
    		$username = $_POST['usname'];
    		$useremail = $_POST['usemail'];
    		$userphone = $_POST['usphone'];
    		$userPass = $_POST['uspass'];
    		$userdob = $_POST['usdob'];
    		$usergender = $_POST['usgender'];
    		
    		
    		$resu="select * from tbl_user where email='$useremail' or phone='$userphone'"; 	   		
    		
    			

		$result=mysqli_query($con,$resu);
		
		if(mysqli_num_rows($result)>0)
		{
		
			echo "account already exists";
		
		}
		else
		{
		
		date_default_timezone_set("asia/kolkata");
		
		$date = date('Y-m-d H:i:s');
		
			$resulta="insert into tbl_user(name,email,phone,password,gender,birthday,login,status,creation,reg_status,block_status)VALUES('$username','$useremail','$userphone','$userPass','$usergender','$userdob','$date','Y','$date','1','0')"; 	   		
    		
    			

		if(mysqli_query($con,$resulta))
		{
			/*
					$maxid="select max(id) from tbl_user";			
			
	         			$rmaxid=mysqli_query($con,$maxid);
	         			$fmaxid= mysqli_fetch_array($rmaxid); 
	         			$idis=$fmaxid["id"];
	         			
	         			$resdtl="insert into tbl_userdetail(country,	state,city,looking,rel_status,smoke,drink,education,language,minage,maxage,eye,skin,work,interest,look_rel,about,partner,	user)VALUES("","","","","","","","","","","","","","","","","","",'$idis')"; 	   		
    		
    				if(mysqli_query($con,$resdtl))
				{
					
		
				}
				else
				{
				
					echo "account not created";
				
				}  */
				
						$resu1="select id from tbl_user where email='$useremail' or phone='$userphone'"; 	
         					
         					$rresu1=mysqli_query($con,$resu1);
	         				$frresu1= mysqli_fetch_array($rresu1); 
	         				$idf=$frresu1["id"];
		

				
				echo $idf;
			
			
		
		}
		else
		{
			echo "try again";
		
		}
		
		}	
		
			
		
    	
    			
	}
}

?>
<?php

if($_SERVER["REQUEST_METHOD"]=="POST")
{	
	include "config.php";	
	
	if(isset($_POST['OnLineUser']))    	
    	{	
    		$load1=$_POST['OnLineUser'];   		
    		
    		
    		
    		if($load1=="1")
    		{ 		
    		$response1=array();
    		$resulta="SELECT tbl_user.id, tbl_user.name,  tbl_user.gender, tbl_user.birthday, tbl_user.profile_pic, tbl_userdetail.city,user_pics.photo1,user_pics.photo2,user_pics.photo3,user_pics.photo4,user_pics.photo5,user_pics.photo6,user_pics.photo7,user_pics.photo8,user_pics.photo9 FROM tbl_user INNER JOIN tbl_userdetail ON tbl_user.id = tbl_userdetail.user INNER JOIN user_pics ON tbl_userdetail.user = user_pics.user where tbl_user.status='Y' LIMIT 0,20";	     	
    		
    		/*
    		
    		$resulta="SELECT tbl_user.id, tbl_user.name,  tbl_user.gender, tbl_user.birthday, tbl_user.profile_pic, tbl_userdetail.city FROM tbl_user INNER JOIN tbl_userdetail ON tbl_user.id = tbl_userdetail.user where tbl_user.status='Y' LIMIT 0,20";	     	
    		
    		
    		*/
    			
		
		//$end=mysql_num_rows($resulta);
		
		
		$result1=mysqli_query($con,$resulta);	
		
		
			if(mysqli_num_rows($result1)>0){
			
					

         			while($row=mysqli_fetch_array($result1))
         			{
         				$citycode1=$row['city'];
	         			$Qscity1="Select * from cities where id='$citycode1'";
	         			$rcity1=mysqli_query($con,$Qscity1);
	         			$fcity1= mysqli_fetch_array($rcity1); 
	         			$city1=$fcity1["name"];	
	         			
	         			
	         			array_push($response1,array(                          		 
	         			 "id"=>$row['id'],                             		 		
      		          		"name"=>$row['name'],
      		          		"gender"=>$row['gender'],	
      		          		"birthday"=>$row['birthday'],
      		          		 "city"=>$city1,                     		 		    		          		          		          				          		
      		          		"profile_pic"=>$row['profile_pic'],
      		          		"photo1"=>$row['photo1'],
      		          		"photo2"=>$row['photo2'],
      		          		"photo3"=>$row['photo3'],
      		          		"photo4"=>$row['photo4'],
      		          		"photo5"=>$row['photo5'],
      		          		"photo6"=>$row['photo6'],
      		          		"photo7"=>$row['photo7'],
      		          		"photo8"=>$row['photo8'],
      		          		"photo9"=>$row['photo9']	      		          		   				          		
		         		));   
         				
         			}
         			
         			echo json_encode($response1);
         			
         			
         			
         			
         		
         		
         		}
    		
    		}
    		else
    		{
    		echo "else";
    		}
    		
		
	

	}
	
	if(isset($_POST['moredta']))    	
    	{		
    		$load=$_POST['moredta'];
    		$mi=$_POST['mored'];   	
    		
    		 		
    		
    		
    		$response=array();
    		
    		if($load=="more")
    		{
		
		
		$resultb="SELECT tbl_user.id, tbl_user.name,  tbl_user.gender, tbl_user.birthday, tbl_user.profile_pic, tbl_userdetail.city,user_pics.photo1,user_pics.photo2,user_pics.photo3,user_pics.photo4,user_pics.photo5,user_pics.photo6,user_pics.photo7,user_pics.photo8,user_pics.photo9 FROM tbl_user INNER JOIN tbl_userdetail ON tbl_user.id = tbl_userdetail.user INNER JOIN user_pics ON tbl_userdetail.user = user_pics.user where tbl_user.status='Y' LIMIT $mi,20";
		
		
		
		$result=mysqli_query($con,$resultb);	
		
		if(mysqli_num_rows($result)>0){
		

         		while($row=mysqli_fetch_array($result))
         			{
         				$citycode1=$row['city'];
	         			$Qscity1="Select * from cities where id='$citycode1'";
	         			$rcity1=mysqli_query($con,$Qscity1);
	         			$fcity1= mysqli_fetch_array($rcity1); 
	         			$city1=$fcity1["name"];	
	         			
	         			
	         			array_push($response,array(                          		 
	         			 "id"=>$row['id'],                             		 		
      		          		"name"=>$row['name'],
      		          		"gender"=>$row['gender'],	
      		          		"birthday"=>$row['birthday'],
      		          		 "city"=>$city1,                     		 		    		          		          		          				          		
      		          		"profile_pic"=>$row['profile_pic'],
      		          		"photo1"=>$row['photo1'],
      		          		"photo2"=>$row['photo2'],
      		          		"photo3"=>$row['photo3'],
      		          		"photo4"=>$row['photo4'],
      		          		"photo5"=>$row['photo5'],
      		          		"photo6"=>$row['photo6'],
      		          		"photo7"=>$row['photo7'],
      		          		"photo8"=>$row['photo8'],
      		          		"photo9"=>$row['photo9']	      		          		   				          		
		         		));   
         				
         			}
       			
       			//echo $mi;  
       			
       			echo json_encode($response);  			
		}
		else
		{
			echo "no more user";
		
		}
		
		}
		else
		{
		
		echo "go in else";	
		
		}
	
	}
	
    	}
    	
?>
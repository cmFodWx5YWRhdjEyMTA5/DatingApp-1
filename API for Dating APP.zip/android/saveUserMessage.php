<?php

if($_SERVER["REQUEST_METHOD"]=="POST")
{
	include "config.php";	
	
	
	if(isset($_POST['SendMessage']))    
    	{	    		
    		
    		$senderid= $_POST['senderid'];
    		$receiverid= $_POST['receiverid'];
    		$usermessage = $_POST['messageis'];
    		$response1=array();
    		
    		$resulta="insert into tbl_message(sender,receiver,message,action)VALUES('$senderid','$receiverid','$usermessage ',0)"; 	
    				
    		if(mysqli_query($con,$resulta))
		{
		
		$qu="SELECT sender, receiver, message, 
ACTION FROM tbl_message
WHERE (
sender ='$senderid'
AND receiver ='$receiverid'
)
ORDER BY id DESC 
LIMIT 1";
			
		$result1=mysqli_query($con,$qu);
		if(mysqli_num_rows($result1)>0){			
					

         			while($row=mysqli_fetch_array($result1))
         			{		
			
	         			array_push($response1,array(   		 
	       				"name"=>"",
      		          		"gender"=>"",	
      		          		"birthday"=>"",      		          		                    		 		    		          		          		          				          		
      		          		"profile_pic"=>"",
      		          		"reciver"=>$row["receiver"],     		          			          		                    		 		    		          		          		          				          		
      		          		"sender"=>$row["sender"],
      		          		"message"=>$row["message"],
      		          		"SendOrRec"=>""      	          		                    		 		    		          		          		          				          		
      		          		
      		          		    		          		   				          		
		         		));      
		         		
		         		
				}
				echo json_encode($response1);
		}
			
		}
		else
		{
			echo "message not sended";
		
		}
    		
		
		
			
		
    	
    			
	}
}

?>
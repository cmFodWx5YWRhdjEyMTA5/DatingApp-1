<?php

if($_SERVER["REQUEST_METHOD"]=="POST")
{	
	include "config.php";	
	
	if(isset($_POST['GetMessage']))    	
    	{	
    		$load1=$_POST['GetMessage']; 
    		$currentuser=$_POST['cuserid'];  		
    		
    		
    		
    		if($load1=="1")
    		{ 
    		
    		/*$resulta="SELECT sender,receiver,message,action FROM tbl_message group by receiver,sender HAVING sender='$currentuser' or receiver='$currentuser' LIMIT 0,20";*/
    		
    		$resulta="SELECT sender AS send
FROM tbl_message
WHERE sender ='$currentuser'
OR receiver ='$currentuser'
UNION 
SELECT receiver
FROM tbl_message
WHERE sender ='$currentuser'
OR receiver ='$currentuser'
LIMIT 0 , 20";
    		
    		
    			
    		
    		$response1=array();
    		/*$resulta="SELECT tbl_user.id, tbl_user.name,  tbl_user.gender, tbl_user.birthday, tbl_user.profile_pic FROM tbl_friends INNER JOIN tbl_user ON tbl_friends.friend= tbl_user.id where tbl_friends.user='$currentuser' or tbl_friends.friend='$currentuser' LIMIT 0,20";	  */   		
		
		//$end=mysql_num_rows($resulta);
		
		
		$result1=mysqli_query($con,$resulta);	
		
		
			if(mysqli_num_rows($result1)>0){			
					

         			while($row=mysqli_fetch_array($result1))
         			{
         				
         				//$rec=$row['receiver'];
         				$send=$row['send'];
         				//msg=$row['message'];
         				//$sendorrecd="";
         					
         					if($send!=$currentuser)
         					{        					
	         				
         					$resu1="SELECT id,name,gender,birthday,profile_pic FROM tbl_user where id='$send'";
         					
         					$rresu1=mysqli_query($con,$resu1);
	         				$frresu1= mysqli_fetch_array($rresu1); 
	         				$idf=$frresu1["id"];
	         				$namef=$frresu1["name"];
	         				$genderf=$frresu1["gender"];
	         				$birthdayf=$frresu1["birthday"];
	         				$profile_picf=$frresu1["profile_pic"];  
	         				
	         				array_push($response1,array(   		 
	       				"name"=>$namef,
      		          		"gender"=>$genderf,	
      		          		"birthday"=>$birthdayf,      		          		                    		 		    		          		          		          				          		
      		          		"profile_pic"=>$profile_picf,     		          		     		          			          		                    		 		    		          		          		          				          		
      		          		"sender"=>$send,      	       		
      		          		 	          		                    		 		    		          		          		          				          		
      		          		
      		          		    		          		   				          		
		         		));     
         					
         					}     					
         				      				
         				      		         			
	         			
	         			
	         			       				
         			}
         			
         			echo json_encode($response1);
         			
         			
         			
         			
         		
         		
         		}
         		else
         		{
         		echo "no row";
         		
         		
         		}
    		
    		}
    		else
    		{
    		echo "else";
    		}
    		
		
	

	}
	
	else if(isset($_POST['moredta']))    	
    	{		
    		$load1=$_POST['moredta']; 
    		$currentuser=$_POST['cuserid'];  
    		$next=$_POST['next'];     	
    		
    		 		
    		
    		
    		$resulta="SELECT user,friend FROM tbl_friends where user ='$currentuser' or friend='$currentuser' LIMIT '$next',20";
    		
    			
    		
    		$response1=array();
    		/*$resulta="SELECT tbl_user.id, tbl_user.name,  tbl_user.gender, tbl_user.birthday, tbl_user.profile_pic FROM tbl_friends INNER JOIN tbl_user ON tbl_friends.friend= tbl_user.id where tbl_friends.user='$currentuser' or tbl_friends.friend='$currentuser' LIMIT 0,20";	  */   		
		
		//$end=mysql_num_rows($resulta);
		
		
		$result1=mysqli_query($con,$resulta);	
		
		
			if(mysqli_num_rows($result1)>0){			
					

         			while($row=mysqli_fetch_array($result1))
         			{
         			
         				$idf="";
         				$namef="";
         				$genderf="";
         				$birthdayf="";
         				$profile_picf="";
         				
         				$u=$row['user'];
         				$f=$row['friend'];        				
         				
         			
         				if($u==$currentuser)
         				{
         				
         				
         				
         					$resu1="SELECT id,name,gender,birthday,profile_pic FROM tbl_user where id='$f'";
         					
         					$rresu1=mysqli_query($con,$resu1);
	         				$frresu1= mysqli_fetch_array($rresu1); 
	         				$idf=$frresu1["id"];
	         				$namef=$frresu1["name"];
	         				$genderf=$frresu1["gender"];
	         				$birthdayf=$frresu1["birthday"];
	         				$profile_picf=$frresu1["profile_pic"];  	
         					
         				
         				}
         				
         				if($f==$currentuser)
         				{
         				
         				
         				
         					$resu2="SELECT id,name,gender,birthday,profile_pic FROM tbl_user where id='$u'";
         					
         					$rresu2=mysqli_query($con,$resu2);
	         				$frresu2= mysqli_fetch_array($rresu2); 
	         				$idf=$frresu2["id"];
	         				$namef=$frresu2["name"];
	         				$genderf=$frresu2["gender"];
	         				$birthdayf=$frresu2["birthday"];
	         				$profile_picf=$frresu2["profile_pic"];  
         				
         				}
         			
         			
         				//$uid=$row['id'];
         			
         				$Qcitycode1="Select city from tbl_userdetail where user='$idf'";
         				$rcitycode1=mysqli_query($con,$Qcitycode1);
	         			$fcitycode= mysqli_fetch_array($rcitycode1); 
	         			$city1=$fcitycode["city"];	
         				
         				
	         			$Qscity1="Select * from cities where id='$city1'";
	         			$rcity1=mysqli_query($con,$Qscity1);
	         			$fcity1= mysqli_fetch_array($rcity1); 
	         			$city2=$fcity1["name"];	
	         			
	         			
	         			
	         			array_push($response1,array(                          		 
	         			 "id"=>$idf,                             		 		
      		          		"name"=>$namef,
      		          		"gender"=>$genderf,	
      		          		"birthday"=>$birthdayf,      		          		                    		 		    		          		          		          				          		
      		          		"profile_pic"=>$profile_picf,
      		          		 "city"=>$city2      		          		   				          		
		         		));            				
         			}
         			
         			echo json_encode($response1);
         			
         			
         			
         			
         		
         		
         		}
		
		}
		else
		{
		
		echo "go in else";	
		
		}
	
	}
	
    	
    	
?>
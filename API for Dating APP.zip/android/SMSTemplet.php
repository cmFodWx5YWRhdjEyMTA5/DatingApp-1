<?php

if($_SERVER["REQUEST_METHOD"]=="POST")
{
	include "config.php";		
	
	if(isset($_POST['Getcountry']))    
    		{  	
    		    	
    		$Qcountry="select * from msgtemplete"; 			

		$resultcountry=mysqli_query($con,$Qcountry);
		
		$response=array();
		/*if(mysqli_num_rows($resultcountry)>0){			
	         		
         		while($h = mysqli_fetch_array($resultcountry)) {
         		
         		array_push($response,array(
                          		"countryid"=>$h["id"],
                          		"countryname"=>$h["name"]));   
         		    		
       			}       			
       			
		echo json_encode($response);

		}*/
		
if(mysqli_num_rows($resultcountry)>0){			
	         		
         		while($h = mysqli_fetch_array($resultcountry)) {
                				$response['templet'][] = array(
                				 'id' => $h['id'],                                              
                                                 'title' => $h['title'],
                                                 'link' => $h['link'],
                                                 'message' => $h['message'],
                                                  'new' => $h['new']
                                                );         		
       			}       			
       			
		echo json_encode($response);

		}
		else
		{
			$response="o row found";
		echo json_encode($response);

		}
		
		
	}
	
	if(isset($_POST['GetItemContent']))    
    		{  	
    		
    		$title=$_POST['GetItemContent'];
    		    	
    		$resu1="select message from msgtemplete where title='$title'"; 			

		
         					
         					$rresu1=mysqli_query($con,$resu1);
	         				$frresu1= mysqli_fetch_array($rresu1); 
	         				$idf=$frresu1["message"];
		

				
	         			
       			
		echo $idf;

		
	}
	else
	{
	
	echo "else";
	}
	
}


?>
<?php

if($_SERVER["REQUEST_METHOD"]=="POST")
{
	include "config.php";		
	
	if(isset($_POST['UserId']))    
    	{	
    		
    		$UserId= $_POST['UserId'];   			
    	
    		$resulta="select * from tbl_user_profile where 	intUserId='$UserId'"; 	
    		
    		
    			

		$result=mysqli_query($con,$resulta);
		$response=array();
		
		

		if(mysqli_num_rows($result)>0){

         		while($row=mysqli_fetch_array($result))
         		{
	         		if($row)
	         		{      		
	         			
		          		array_push($response,array(
                          		"intId"=>$row["intId"],                             		 		
      		          		"intUserId"=>$row["intUserId"],
      		          		"profile_heading"=>$row["profile_heading"],
      		          		"own_desc"=>$row["own_desc"],
      		          		"partner_desc"=>$row["partner_desc"],
      		          		"sex"=>$row["sex"],
      		          		"hair_color"=>$row["hair_color"],
      		          		"hair_length"=>$row["hair_length"],
      		          		"hair_type"=>$row["hair_type"],
      		          		"eye_wear"=>$row["eye_wear"],
      		          		"eye_color"=>$row["eye_color"],
      		          		"height"=>$row["height"],
      		          		"weight"=>$row["weight"],
      		          		"body_type"=>$row["body_type"],
      		          		"ethnicity"=>$row["ethnicity"],
      		          		"appearance"=>$row["appearance"],
      		          		"smoke"=>$row["smoke"],
      		          		"material_status"=>$row["material_status"],
      		          		"children"=>$row["children"],      		          		
      		          		"more_children"=>$row["more_children"],
      		          		"occuption"=>$row["occuption"],
      		          		"relocate"=>$row["relocate"],
      		          		"looking_for_merriage"=>$row["looking_for_merriage"],
      		          		"looking_for_frnd"=>$row["looking_for_frnd"],
      		          		"looking_country"=>$row["looking_country"],
      		          		"looking_state"=>$row["looking_state"],
      		          		"nationality"=>$row["nationality"],      		
      		          		"education"=>$row["education"],                             		 		
      		          		"religion"=>$row["religion"],
      		          		"born"=>$row["born"],
      		          		"religion_values"=>$row["religion_values"],
      		          		"complexion"=>$row["complexion"],
      		          		"facial_hair"=>$row["facial_hair"],
      		          		"health_status"=>$row["health_status"],
      		          		"drink"=>$row["drink"],
      		          		"eating_habbit"=>$row["eating_habbit"],
      		          		"emp_status"=>$row["emp_status"],
      		          		"income"=>$row["income"],
      		          		"home_type"=>$row["home_type"],
      		          		"live_status"=>$row["live_status"],
      		          		"residancy_status"=>$row["residancy_status"],
      		          		"relation_status"=>$row["relation_status"],
      		          		"appearance"=>$row["appearance"],
      		          		"relocate_status"=>$row["relocate_status"],
      		          		"lang_spoken"=>$row["lang_spoken"],
      		          		"attand_religious_services"=>$row["attand_religious_services"],      		          		
      		          		"wear_niqab"=>$row["wear_niqab"],
      		          		"wear_hijab"=>$row["wear_hijab"],
      		          		"read_quran"=>$row["read_quran"],
      		          		"polygamy"=>$row["polygamy"],
      		          		"family_values"=>$row["family_values"],
      		          		"profile_creator"=>$row["profile_creator"],
      		          		"createdate"=>$row["createdate"],      		          		
      		          			          				          		
		         		));
		        
	        		}
	        		else
	        		{
		        		$response["error"] = TRUE;
		        		echo json_encode($response);
	        		}              

       			}
       			
       			
       			
       			$response["item"] =$response;
		echo json_encode($response);

		}
		
	
		
}

}

?>
<?php

if($_SERVER["REQUEST_METHOD"]=="POST")
{
	include "config.php";	
	
	
	if(isset($_POST['UserLogin']))    
    	{	
    		
    		
    		$userEmail = $_POST['loginEmail'];
    		$userPass = $_POST['loginPassword'];	
		
    	
    		$resulta="select * from tbl_user where email='$userEmail' and password='$userPass'"; 	   		
    		
    		    		
    		$blockstatus=mysqli_query($con,$resulta);
    		$fblockstatus= mysqli_fetch_array($blockstatus); 
    		$block=$fblockstatus["block_status"];
    		
    		
    		if($block==0)
    		{	

		$result=mysqli_query($con,$resulta);
		$response=array();
		
		

		if(mysqli_num_rows($result)>0){

         		while($row=mysqli_fetch_array($result))
         		{      		
         				
         		
         		
	         		if($row)
	         		{
		          		array_push($response,array(
                          		"id"=>$row["id"],
                          		"reg_status"=>$row["reg_status"],                		 		
      		          		"email"=>$row["email"],
      		          		"password"=>$row["password"]       				          		
		         		));
		        
	        		}
	        		else
	        		{
		        		$response["error"] = TRUE;
		        		echo json_encode($response);
	        		}              

       			}      			
       			
       			
       		$response["item"] =$response;	
		echo json_encode($response);

		}
		else
		{
			$response=0;
			echo json_encode($response);
		}
		
		
		}
		else
		{
			
			echo "blocked";
		
		
		}
		
	
		
}


if(isset($_POST['CompleteProfile']))    
    	{	
    		
    		
    		$userEmail = $_POST['loginEmail'];
    		$userPass = $_POST['loginPassword'];	
		
    	
    		$resulta="select * from tbl_user where email='$userEmail' and password='$userPass'"; 	   		
    		
    		    		
    		$blockstatus=mysqli_query($con,$resulta);
    		$fblockstatus= mysqli_fetch_array($blockstatus); 
    		$block=$fblockstatus["block_status"];
    		
    		
    		if($block==0)
    		{	

		$result=mysqli_query($con,$resulta);
		$response=array();
		
		

		if(mysqli_num_rows($result)>0){

         		while($row=mysqli_fetch_array($result))
         		{      		   				
         		        		
	         		if($row)
	         		{
		          		array_push($response,array(                          		
                          		"id"=>$row["id"],                             		 		
      		          		"name"=>$row["name"],
      		          		"email"=>$row["email"],
                          		"phone"=>$row["phone"],
      		          		"password"=>$row["password"],
      		          		"gender"=>$row["gender"],
      		          		"birthday"=>$row["birthday"],
      		          		"profile_pic"=>$row["profile_pic"],
      		          		"cover_pic"=>$row["cover_pic"],
      		          		"login"=>$row["login"],
      		          		"status"=>$row["status"],
      		          		"creation"=>$row["creation"],
      		          		"reg_status"=>$row["reg_status"]                		 		
      		          		       		          				          		
		         		));
		        
	        		}
	        		           

       			}     		     			
       			
       		
		echo json_encode($response);

		}
		else
		{
			$response=0;
			echo json_encode($response);
		}
		
		
		}
		else
		{
			
			echo "blocked";
		
		
		}
		
	
		
}






if(isset($_POST['loginDtl']))    
    	{	
    	$userid = $_POST['loginDtl'];  
    	
    		
    				$resulta="SELECT tbl_user.id, tbl_user.name, tbl_user.email, tbl_user.phone, tbl_user.password, tbl_user.gender, tbl_user.birthday, tbl_user.profile_pic, tbl_user.cover_pic, tbl_user.login, tbl_user.status, tbl_user.creation, tbl_user.reg_status, tbl_userdetail.id, tbl_userdetail.country, tbl_userdetail.state, tbl_userdetail.city, tbl_userdetail.looking, tbl_userdetail.rel_status, tbl_userdetail.smoke, tbl_userdetail.drink, tbl_userdetail.education, tbl_userdetail.language, tbl_userdetail.minage, tbl_userdetail.maxage, tbl_userdetail.eye, tbl_userdetail.skin, tbl_userdetail.work, tbl_userdetail.interest, tbl_userdetail.look_rel, tbl_userdetail.about, tbl_userdetail.partner, tbl_userdetail.user
FROM tbl_user
INNER JOIN tbl_userdetail ON tbl_user.id = tbl_userdetail.user
WHERE tbl_user.id='$userid'";
    		
    			

		$result=mysqli_query($con,$resulta);
		$response=array();
		
		

		if(mysqli_num_rows($result)>0){

         		while($row=mysqli_fetch_array($result))
         		{
         		
         				$countrycode=$row['country'];
	         			$Qcountry="Select * from countries where id='$countrycode'";
	         			$rcountry=mysqli_query($con,$Qcountry);
	         			$fountry= mysqli_fetch_array($rcountry); 
	         			$country=$fountry["name"];
	         			
	         			$statecode=$row['state'];
	         			$Qstate="Select * from states where id='$statecode'";
	         			$rstate=mysqli_query($con,$Qstate);
	         			$fstate= mysqli_fetch_array($rstate); 
	         			$state=$fstate["name"];
	         			
	         			$citycode=$row['city'];
	         			$Qscity="Select * from cities where id='$citycode'";
	         			$rcity=mysqli_query($con,$Qscity);
	         			$fcity= mysqli_fetch_array($rcity); 
	         			$city=$fcity["name"];	
	         			
	         			
	         			
	         			
	         			$LookingAgeid=$row['intLookAgeId'];
	         			$QAge="Select * from tbl_looking_for_age where intId='$LookingAgeid'";
	         			$rAge=mysqli_query($con,$QAge);
	         			$fAge= mysqli_fetch_array($rAge); 
	         			$seekingAgestart=$fAge["start_age"];
	         			$seekingAgeend=$fAge["end_age"];		  
         		
         		
         		
	         		if($row)
	         		{
		          		array_push($response,array(
                          		"id"=>$row["id"],                             		 		
      		          		"name"=>$row["name"],
      		          		"email"=>$row["email"],
      		          		"phone"=>$row["phone"],
      		          		"password"=>$row["password"],
      		          		"gender"=>$row["gender"],
      		          		"birthday"=>$row["birthday"],
      		          		"profile_pic"=>$row["profile_pic"],
      		          		"cover_pic"=>$row["cover_pic"],
      		          		"login"=>$row["login"],
      		          		"status"=>$row["status"],
      		          		"creation"=>$row["creation"],
      		          		"reg_status"=>$row["reg_status"],
      		          		"country_code"=>$row["country"],
      		          		"state_code"=>$row["state"],
      		          		"city_code"=>$row["city"],
      		          		"looking"=>$row["looking"],
      		          		"rel_status"=>$row["rel_status"],
      		          		"smoke"=>$row["smoke"],
      		          		"drink"=>$row["drink"],
      		          		"education"=>$row["education"],
      		          		"language"=>$row["language"],
      		          		"minage"=>$row["minage"],
      		          		"maxage"=>$row["maxage"],
      		          		"eye"=>$row["eye"],
      		          		"skin"=>$row["skin"],
      		          		"work"=>$row["work"],
      		          		"interest"=>$row["interest"],
      		          		"look_rel"=>$row["look_rel"],
      		          		"about"=>$row["about"],    		          		
      		          		"partner"=>$row["partner"],
      		          		"user"=>$row["user"],      		          		
      		          		"country"=>$country,  
      		          		"state"=>$state,  
      		          		"city"=>$city     	
      		          		
      		          		
      		          		
      		          			          		
      		          		
		          				          		
		         		));
		        
	        		}
	        		else
	        		{
		        		$response["error"] = TRUE;
		        		echo json_encode($response);
	        		}              

       			}      			
       			
       			
       		$response["item"] =$response;	
		echo json_encode($response);

		}
		else
		{
			$response=0;
			echo json_encode($response);
		}
    	
    	
    	
    	
    	
    	
    		
    		
    			
    			
    		
    
		
	
		
}

	if(isset($_POST['UserPhotos']))    
    	{
    	
    	//$userEmail = $_POST['loginEmail'];
    		
    		$useid = $_POST['userid'];	
		
    	
    		$resulta="select * from  user_pics where user='$useid'"; 	
    		
    		
    			

		$result=mysqli_query($con,$resulta);
		$response=array();
		
		if(mysqli_num_rows($result)>0){

         		while($row=mysqli_fetch_array($result))
         		{
         				if($row)
	         		{
		          		array_push($response,array(
                          		"id"=>$row["id"],                             		 		
      		          		"photo1"=>$row["photo1"],  
      		          		"photo2"=>$row["photo2"],  
      		          		"photo3"=>$row["photo3"],  
      		          		"photo4"=>$row["photo4"],  
      		          		"photo5"=>$row["photo5"],  
      		          		"photo6"=>$row["photo6"],  
      		          		"photo7"=>$row["photo7"],  
      		          		"photo8"=>$row["photo8"],  
      		          		"photo9"=>$row["photo9"],         		
      		          		
      		          		
      		          			          		
      		          		
		          				          		
		         		));
		        
	        		}
	        		else
	        		{
		        		$response["error"] = TRUE;
		        		echo json_encode($response);
	        		}              

         				
	         	}
	         	
	         	$response["item"] =$response;	
			echo json_encode($response);
	         }
	         else
	         {
	         		$response ='no photos';	
			echo json_encode($response);
	         }
    	
    	}

}

?>
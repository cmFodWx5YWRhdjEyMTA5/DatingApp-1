<?php

if($_SERVER["REQUEST_METHOD"]=="POST")
{
	include "config.php";		
	
	if(isset($_POST['Getcountry']))    
    		{  	
    		    	
    		$Qcountry="select * from countries"; 			

		$resultcountry=mysqli_query($con,$Qcountry);
		
		$response=array();
		/*if(mysqli_num_rows($resultcountry)>0){			
	         		
         		while($h = mysqli_fetch_array($resultcountry)) {
         		
         		array_push($response,array(
                          		"countryid"=>$h["id"],
                          		"countryname"=>$h["name"]));   
         		    		
       			}       			
       			
		echo json_encode($response);

		}*/
		

		if(mysqli_num_rows($resultcountry)>0){			
	         		
         		while($h = mysqli_fetch_array($resultcountry)) {
                				$response['country'][] = array(
                				 'id' => $h['id'],                                              
                                                 'name' => $h['name']
                                                );        		
       			}       			
       			
		echo json_encode($response);

		}
		else
		{
			$response="o row found";
		echo json_encode($response);

		}
		
		
	}
	
	else if(isset($_POST['GetState']))    
    	{  	
    	
    		$getcountryname=$_POST['sendCountryName'];    		
    		
    		$countryQuery="select * from countries where name='$getcountryname'";    		
    		$rconuntryquery=mysqli_query($con,$countryQuery);
    		$fcountryid= mysqli_fetch_array($rconuntryquery); 
    		$locationidis=$fcountryid["id"];
    	
    	
    	
    	
    		    	
    		$Qstate="select * from states where country_id='$locationidis'"; 			

		$resultstate=mysqli_query($con,$Qstate);
		
		$response=array();
		/*if(mysqli_num_rows($resultcountry)>0){			
	         		
         		while($h = mysqli_fetch_array($resultcountry)) {
         		
         		array_push($response,array(
                          		"countryid"=>$h["id"],
                          		"countryname"=>$h["name"]));   
         		    		
       			}       			
       			
		echo json_encode($response);

		}*/
		

		if(mysqli_num_rows($resultstate)>0){			
	         		
         		while($h = mysqli_fetch_array($resultstate)) {
                				$response['state'][] = array(
                				 'id' => $h['id'],                                              
                                                 'name' => $h['name']
                                                );        		
       			}       			
       			
		echo json_encode($response);

		}
		
		else
		{
			
		echo json_encode($locationidis);

		}

		
	}
	
	else if(isset($_POST['GetCity']))    
    	{  	
    		
    		$getstatename=$_POST['sendStateName'];    		
    		
    		$stateQuery="select * from states where name='$getstatename'";    		
    		$rstatequery=mysqli_query($con,$stateQuery);
    		$fstateid= mysqli_fetch_array($rstatequery); 
    		$locationidis=$fstateid["id"];
    	
    	
    	
    	
    		    	
    		$Qcity="select * from cities where state_id='$locationidis'"; 			

		$resultcity=mysqli_query($con,$Qcity);
		
		$response=array();
		/*if(mysqli_num_rows($resultcountry)>0){			
	         		
         		while($h = mysqli_fetch_array($resultcountry)) {
         		
         		array_push($response,array(
                          		"countryid"=>$h["id"],
                          		"countryname"=>$h["name"]));   
         		    		
       			}       			
       			
		echo json_encode($response);

		}*/
		

		if(mysqli_num_rows($resultcity)>0){			
	         		
         		while($h = mysqli_fetch_array($resultcity)) {
                				$response['city'][] = array(
                				 'id' => $h['id'],                                              
                                                 'name' => $h['name']
                                                );        		
       			}       			
       			
		echo json_encode($response);

		}
		
		else
		{
			
		echo json_encode($locationidis);

		}

	}
	else if(isset($_POST['uProfileUpdate']))    
    	{  	
    	
    		$ufname=$_POST['ufname'];
    		$ulname=$_POST['ulname'];
    		$statename=$_POST['uemail'];
    		$uemail=$_POST['ugender'];
    		$statename=$_POST['useekinggender'];
    		$useekinggender=$_POST['ucountry'];
    		$ustate=$_POST['ustate'];    		
    		$ucity=$_POST['ucity'];
    		$udob=$_POST['udob'];
    		
    		
 
    	
    	
    	
    	
    	
    		$statename=$_POST['stateName'];
    		
    		
    		
    		$statQuery="select * from location where name='$statename'";
    		
    		$rstatquery=mysqli_query($con,$statQuery);
    		$fstateid= mysqli_fetch_array($rstatquery); 
    		$locationidis=$fstateid["location_id"];
    	
    	
    					
    	
    	
    	
    		
    		    	
    		$Qcountry="select * from location where parent_id ='$locationidis'"; 			

		$resultcountry=mysqli_query($con,$Qcountry);
		
		$response=array();		
		

		if(mysqli_num_rows($resultcountry)>0){			
	         		
         		while($h = mysqli_fetch_array($resultcountry)) {
                				$response['state'][] = array(
                				 'location_id' => $h['location_id'],                                              
                                                 'name' => $h['name']
                                                );        		
       			}       			
       			
		echo json_encode($response);

		}
		
	}
		
		
		


}


?>